"""Build a shared, reproducible scene-layout JSON for Godot and preview renderers.
Only standard Python library is required. Outputs are original low-poly modular geometry.
All distances are metres. House pieces are LOCAL; world props are WORLD coordinates.
"""
import json, math, random
from pathlib import Path
OUT = Path(__file__).resolve().parents[1] / 'assets' / 'street_layout.json'
r = random.Random(284011)
P = []
H = []

def part(collection, kind, at, size, color, tex='', roof=False, rot=None, solid=False, emissive=False):
    obj={'kind':kind, 'at':[round(float(x),3) for x in at], 'size':[round(float(x),3) for x in size], 'color':color}
    if tex: obj['tex']=tex
    if roof: obj['roof']=True
    if rot: obj['rot']=rot
    if solid: obj['solid']=True
    if emissive: obj['emissive']=True
    collection.append(obj)
    return obj

def bx(a,p,s,c,tex='',roof=False,rot=None,solid=False,emissive=False): return part(a,'box',p,s,c,tex,roof,rot,solid,emissive)
def sph(a,p,s,c):return part(a,'sphere',p,s,c)
def cyl(a,p,s,c):return part(a,'cylinder',p,s,c)
def cone(a,p,s,c,rot=None):return part(a,'cone',p,s,c,rot=rot)
def gem(a,p,s,c,roof=False):return part(a,'crystal',p,s,c,roof=roof,emissive=True)

# Shared ground (a single natural ground mesh; narrow stone street is the focus).
bx(P,(0,-0.47,-8),(104,0.94,140),'#819178','grass',solid=True)
bx(P,(0,0.020,-4),(9.7,0.052,98),'#d5c9af','cobble')
for side in [-1,1]:
    bx(P,(side*5.03,0.14,-4),(0.28,0.28,97),'#928b7c','stone')
    bx(P,(side*7.3,0.001,-4),(4.45,0.028,97),'#827b69','dirt')
# plaza turning / visual start of street
bx(P,(0,0.026,34),(15.2,0.054,13.4),'#d9cfb7','cobble')
for dz in [40,27]: bx(P,(0,0.04,dz),(15.2,0.065,0.16),'#bcb5a6','stone')

# Architecture: each house uses the SAME floor/wall/roof construction kit, with unique shape details.
def create_house(name,title,center,yaw,style):
    a=[]
    palette={
        'tavern':  {'plaster':'#c3baaa','roof':'#6e8291','wood':'#7a5e46','trim':'#5f4d40','tile':'#a7a69e'},
        'forge':   {'plaster':'#b0a79b','roof':'#545d66','wood':'#6c5546','trim':'#493e38','tile':'#8b887e'},
        'alchemy': {'plaster':'#b5b9b0','roof':'#607771','wood':'#736453','trim':'#4e5651','tile':'#9c9f96'},
    }[style]
    C=palette
    stone='#bcb1a0'
    # foundation and inside floor (true walkable door gap, roof with no collision)
    bx(a,(0,0.11,0),(7.25,0.22,7.3),'#a8a093','stone')
    bx(a,(0,0.236,0),(6.62,0.065,6.68),'#d0b18c','wood')
    # main wall panels, 2m front door opening at x=0
    bx(a,(-3.32,2.11,0),(0.34,3.78,6.72),C['plaster'],'plaster',solid=True)
    bx(a,(3.32,2.11,0),(0.34,3.78,6.72),C['plaster'],'plaster',solid=True)
    bx(a,(0,2.11,-3.34),(6.65,3.78,0.34),C['plaster'],'plaster',solid=True)
    for x in [-2.17,2.17]:
        bx(a,(x,2.11,3.34),(2.31,3.78,0.34),C['plaster'],'plaster',solid=True)
    bx(a,(0,3.48,3.34),(2.08,1.04,0.34),C['plaster'],'plaster',solid=True)
    # timber modular posts and belt braces
    for x in [-3.26,3.26]:
        for z in [-3.25,3.25]: bx(a,(x,2.12,z),(0.31,4.21,0.34),C['wood'],'wood')
    for z in [-3.52,3.52]:
        for y in [0.55,3.9]: bx(a,(0,y,z),(6.94,0.22,0.22),C['wood'],'wood')
    for x in [-3.48,3.48]:
        bx(a,(x,3.95,0),(0.23,0.20,6.98),C['wood'],'wood')
    # diagonal timber accents to break rectangular facade
    for x in [-2.5,2.5]:
        bx(a,(x,3.15,3.54),(0.15,1.1,0.18),C['wood'],'wood',rot=[0,0,-26 if x<0 else 26])
    # windows: lit glass planes framed with timber, small cross bar and sill
    for x in [-2.14,2.14]:
        bx(a,(x,2.4,3.54),(1.00,1.05,0.09),'#c1a675','glass',emissive=True)
        for off in [-0.52,0.52]: bx(a,(x+off,2.4,3.62),(0.10,1.2,0.17),C['trim'],'wood')
        for yy in [1.85,2.95]: bx(a,(x,yy,3.62),(1.17,0.12,0.17),C['trim'],'wood')
        bx(a,(x,2.4,3.65),(0.10,1.1,0.08),C['trim'],'wood')
        bx(a,(x,2.32,-3.54),(0.88,0.98,0.07),'#b6a279','glass')
    bx(a,(0,3.22,3.55),(2.28,0.19,0.19),C['trim'],'wood')
    # front porch & doorstep deliberately not collision to keep step traversable
    bx(a,(0,0.13,4.22),(2.8,0.24,1.42),stone,'stone')
    # door frame, opening remains unobstructed
    for x in [-1.04,1.04]: bx(a,(x,1.54,3.57),(0.22,2.77,0.26),C['trim'],'wood')
    # big sign hangs above door; text via Label3D at runtime
    bx(a,(0,3.98,3.95),(3.28,0.73,0.16),'#3f4446','wood')
    bx(a,(0,4.36,3.86),(3.47,0.13,0.22),'#ad9972','wood')
    bx(a,(0,3.64,3.86),(3.47,0.13,0.22),'#ad9972','wood')
    # sloping slate roof uses ALPHA ONLY when inside, ridge along local Z
    bx(a,(-1.79,4.93,0),(4.30,0.28,8.11),C['roof'],'slate',roof=True,rot=[0,0,26])
    bx(a,( 1.79,4.93,0),(4.30,0.28,8.11),C['roof'],'slate',roof=True,rot=[0,0,-26])
    bx(a,(0,5.88,0),(0.38,0.30,8.3),'#53616a','slate',roof=True)
    # decorative shallow roof tiles/battens, all part of fading group
    for z in [-3.45,-2.50,-1.55,-0.60,0.35,1.30,2.25,3.20]:
        bx(a,(-1.83,4.99,z),(4.24,0.055,0.10),'#8e9a9c','slate',roof=True,rot=[0,0,26])
        bx(a,( 1.83,4.99,z),(4.24,0.055,0.10),'#859296','slate',roof=True,rot=[0,0,-26])
    # ridge end highlights, will fade as well
    for z in [-4.12,4.12]: sph(a,(0,5.94,z),(.25,.3,.25),'#adb09f')
    # lantern glass next to door (not physically obstructive)
    for x in [-1.51,1.51]:
        bx(a,(x,2.64,3.75),(.26,.44,.24),'#e7b96a','glass',emissive=True)
        bx(a,(x,2.93,3.75),(.33,.12,.32),C['trim'],'wood')
    # interior furniture, customized by building type
    if style=='tavern':
        # counter at back; tables along left and right, mugs/candle
        bx(a,(0,.96,-2.10),(4.15,.23,1.05),C['wood'],'wood')
        for x in [-1.65,1.65]: bx(a,(x,.52,-2.10),(.48,.95,.52),C['trim'],'wood')
        for x,z in [(-1.45,1.05),(1.5,0.55)]:
            bx(a,(x,.75,z),(1.45,.16,1.0),C['wood'],'wood')
            bx(a,(x,.34,z),(.28,.65,.28),C['trim'],'wood')
            bx(a,(x-.35,.94,z),(.20,.23,.2),'#c5b4a0','plaster')
        bx(a,(2.45,1.21,-2.63),(0.67,2.1,.55),C['trim'],'wood')
        for y in [.7,1.6,2.4]:
            bx(a,(2.4,y,-2.28),(.53,.13,.10),'#b2996d','wood')
        # outdoor barrel
        for p in [(-3.9,.53,2.7),(-4.45,.53,2.85)]: cyl(a,p,(.9,1.05,.9),'#82634a')
    elif style=='forge':
        # chimney and furnace behind house exterior, furnace glowing inside
        bx(a,(-2.58,5.5,-2.2),(.95,4.0,.98),'#9e9183','stone')
        bx(a,(-2.58,7.50,-2.2),(1.3,.27,1.35),'#756e66','stone')
        bx(a,(-2.2,.91,-2.35),(2.05,1.35,1.2),'#5a5653','stone')
        bx(a,(-2.2,1.35,-1.69),(1.15,.47,.10),'#e8a252','glass',emissive=True)
        bx(a,(1.5,.78,-1.2),(1.06,.26,1.05),'#5a6060','stone')
        bx(a,(1.5,.46,-1.2),(.37,.65,.39),'#6b625c','stone')
        bx(a,(1.5,1.08,-1.2),(.57,.15,.66),'#777c78','stone')
        # weapon rack 
        for x in [-2.4,-1.6]: bx(a,(x,1.5,2.1),(.1,2.5,.1),'#6d726e','stone')
        bx(a,(-2,2.1,2.1),(1.6,.13,.1),'#655346','wood')
        for xx in [1.6,2.0,2.4]:bx(a,(xx,.3,2.2),(.48,.6,.6),'#736353','wood')
    elif style=='alchemy':
        for x in [-2.55,2.55]:
            bx(a,(x,1.30,-1.70),(.46,2.4,2.55),'#6b6c60','wood')
            for z in [-2.35,-1.60,-.85]:
                for yy in [.65,1.55,2.4]:
                    gem(a,(x,yy,z),(.21,.45,.21),'#718c99' if yy <2 else '#a38a9a')
        bx(a,(0,.79,.45),(2.25,.22,1.25),'#7f6c55','wood')
        bx(a,(0,.41,.45),(.52,.75,.52),'#756554','wood')
        for x in [-.75,0,.75]:
            gem(a,(x,1.23,.46),(.24,.72,.24),'#8ba5a1')
        # tiny hanging shop orb
        gem(a,(0,5.95,0),(.62,1.13,.62),'#7d9fa5',roof=True)
    H.append({'id':name,'label':title,'at':center,'yaw':yaw,'inside':[3.15,3.08], 'parts':a})

create_house('tavern','Таверна «Старый дуб»',[-10,0,11],90,'tavern')
create_house('forge','Кузница', [10,0,-7],-90,'forge')
create_house('alchemy','Магическая лавка',[-10,0,-27],90,'alchemy')

# Reusable 3D street decoration: lamps, flags, trees, benches, fences.
def street_lamp(x,z):
    cyl(P,(x,1.75,z),(.22,3.5,.22),'#5c4f42')
    bx(P,(x,3.55,z),(.54,.18,.53),'#3c4443','wood')
    bx(P,(x,3.89,z),(.56,.52,.55),'#efc88e','glass',emissive=True)
    cone(P,(x,4.32,z),(1.02,.55,1.02),'#5b656d')
    bx(P,(x,0.18,z),(.65,.32,.65),'#9b9485','stone')
for x,z in [(-5.55,25.2),(5.6,12),(5.5,-24),(-5.6,-40)]:street_lamp(x,z)

def flag(x,z,blue='#5d6977'):
    cyl(P,(x,2.55,z),(.10,5.0,.10),'#6c5c4a')
    bx(P,(x+.5,4.55,z), (1.14,.085,.085),'#ac976c','wood')
    bx(P,(x+.64,3.60,z),(1.17,1.67,.06),blue,'cloth')
    bx(P,(x+.64,3.11,z),(1.0,.10,.10),'#9d8663','wood')
for pos in [(-6.35,-46),(6.35,-46),(6.4,34)]:flag(*pos)

def tree(x,z,s=1):
    cyl(P,(x,1.15*s,z),(.58*s,2.3*s,.58*s),'#665847')
    sph(P,(x,3.18*s,z),(3.4*s,3.4*s,3.2*s),'#64785f')
    sph(P,(x+1.25*s,3.05*s,z+.34*s),(2.1*s,2.6*s,2.1*s),'#72896d')
    sph(P,(x-1*s,3.7*s,z-.6*s),(2.35*s,2.3*s,2.45*s),'#596f58')
for x,z,s in [(-21,8,.92),(19,-5,.86),(-21,-30,.9),(15,23,1.08),(21,-35,1.0),(-15,37,.91),(34,0,1.2),(-30,-14,.9)]:tree(x,z,s)

# mild hills in the distance, few stones and brush -- avoids fantasy city overload
for x,z,s in [(-42,-51,1),(39,-51,1.15),(-43,45,1),(38,44,.8)]:
    sph(P,(x,-.35,z),(14*s,3*s,18*s),'#728269')
for i in range(75):
    x=r.uniform(-28,28);z=r.uniform(-46,47)
    if abs(x)<5.4 or (abs(x+10)<6.2 and abs(z-11)<6) or (abs(x-10)<6.2 and abs(z+7)<6) or (abs(x+10)<6.2 and abs(z+27)<6):continue
    s=r.uniform(.3,.7)
    sph(P,(x,.16*s,z),(.55*s,.45*s,.60*s),r.choice(['#758a6c','#8a906d','#8d876e']))
for x,z in [(-5.6,4),(-5.5,-21),(5.7,-11)]:
    for j in range(4):
        px=x+r.uniform(-.9,.9);pz=z+r.uniform(-1.7,1.7)
        sph(P,(px,.28,pz),(.28,.45,.28),'#b3a58a')
# crystals on the edge of a tiny square (not in the middle of the main path)
cyl(P,(6.15,.32,28.2),(1.72,.58,1.72),'#9e9e94')
cyl(P,(6.15,.58,28.2),(1.33,.23,1.33),'#727d7e')
gem(P,(6.15,2.0,28.2),(.88,2.55,.88),'#6b9daa')
for ox,oz in [(-1.05,0),(1.06,.1),(0,-1.0)]:gem(P,(6.15+ox,1.13,28.2+oz),(.32,.95,.32),'#8aa3a6')
# distant walk-through town gate with no solid geometry in the central aisle
for x in [-7.5,7.5]:
    bx(P,(x,3.2,-51),(3.1,6.4,3.6),'#a49f91','stone',solid=True)
    cone(P,(x,7.3,-51),(4.0,2.5,4.1),'#526677')
    for y in [2.1,4.3]:bx(P,(x, y,-49.05),(.85,.85,.09),'#4b5a61','wood')
bx(P,(0,6.48,-51),(12.05,1.0,2.30),'#a7a195','stone')
for side in [-1,1]:
    bx(P,(side*20,2.0,-51),(23,4,1.2),'#a49d8f','stone',solid=True)
# wooden benches, crates and barrels next to house fronts
for x,z in [(-5.7,15.7),(5.55,-1.9)]:
    bx(P,(x,.70,z),(1.86,.14,.65),'#8d7154','wood')
    for dx in [-.71,.71]: bx(P,(x+dx,.36,z),(.18,.65,.56),'#73583e','wood')
for x,z in [(14,11),(17,-12),(-15,-18)]:
    bx(P,(x,.44,z),(.9,.9,.92),'#8a735d','wood')
    bx(P,(x,.9,z),(.92,.10,.94),'#604e3c','wood')

layout = {'version':3, 'spawn':[0,.24,25.0], 'camera_yaw':0, 'world_parts':P,'buildings':H,'note':'Coordinates in metres, all original mesh primitives, no external proprietary assets'}
OUT.write_text(json.dumps(layout,ensure_ascii=False,separators=(',',':')),'utf-8')
print('street:',len(P),'world meshes;',*(f"{h['label']}: {len(h['parts'])}" for h in H))
print('saved',OUT,'bytes',OUT.stat().st_size)
