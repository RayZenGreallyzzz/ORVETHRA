"""Render street_layout.json geometry in VTK as an HONEST geometry preview.
Not a Godot screenshot: ignores textures, materials and gameplay shaders.
The objects and their placements match the shipped layout exactly.
"""
import json, math
from pathlib import Path
import numpy as np
import vtk
from PIL import Image, ImageDraw, ImageFont, ImageEnhance
ROOT=Path(__file__).resolve().parents[1]
DATA=json.loads((ROOT/'assets/street_layout.json').read_text())

def col(v):
    return tuple(int(v.lstrip('#')[i:i+2],16)/255 for i in (0,2,4))

def T(v):
    m=np.eye(4)
    m[:3,3]=v
    return m

def S(v):
    m=np.eye(4)
    m[0,0],m[1,1],m[2,2]=v
    return m

def R_axis(t,k):
    a=math.radians(t);c,s=math.cos(a),math.sin(a);m=np.eye(4)
    if k=='x':m[:3,:3]=[[1,0,0],[0,c,-s],[0,s,c]]
    if k=='y':m[:3,:3]=[[c,0,s],[0,1,0],[-s,0,c]]
    if k=='z':m[:3,:3]=[[c,-s,0],[s,c,0],[0,0,1]]
    return m

renderer=vtk.vtkRenderer()
renderer.SetBackground(0.66,0.73,0.75)
renderer.SetBackground2(0.86,0.84,0.78)
renderer.GradientBackgroundOn()
renderer.AutomaticLightCreationOff()
lighting=vtk.vtkLight()
lighting.SetLightTypeToSceneLight()
lighting.SetPosition(-30,55,45)
lighting.SetFocalPoint(0,0,0)
lighting.SetIntensity(1.55)
renderer.AddLight(lighting)
fill=vtk.vtkLight()
fill.SetLightTypeToSceneLight()
fill.SetPosition(40,30,-50)
fill.SetFocalPoint(0,0,0)
fill.SetIntensity(.38)
renderer.AddLight(fill)

def primitive(k):
    if k=='box':
        s=vtk.vtkCubeSource();s.SetXLength(1);s.SetYLength(1);s.SetZLength(1)
    elif k=='sphere':
        s=vtk.vtkSphereSource();s.SetRadius(.5);s.SetThetaResolution(9);s.SetPhiResolution(8)
    elif k in ('cylinder','cone'):
        if k=='cone':
            s=vtk.vtkConeSource();s.SetResolution(8);s.SetRadius(.5);s.SetHeight(1);s.SetDirection(0,1,0)
        else:
            s=vtk.vtkCylinderSource();s.SetResolution(9);s.SetRadius(.5);s.SetHeight(1)
    elif k=='crystal':
        points=vtk.vtkPoints()
        for p in [(0,.5,0),(0,-.5,0),(.5,0,0),(0,0,.5),(-.5,0,0),(0,0,-.5)]:points.InsertNextPoint(*p)
        faces=vtk.vtkCellArray()
        for i in range(4):
            a=2+i;b=2+(i+1)%4
            for ids in [(0,a,b),(1,b,a)]:
                tri=vtk.vtkTriangle()
                for idx,v in enumerate(ids):tri.GetPointIds().SetId(idx,v)
                faces.InsertNextCell(tri)
        poly=vtk.vtkPolyData();poly.SetPoints(points);poly.SetPolys(faces)
        s=vtk.vtkTrivialProducer();s.SetOutput(poly)
    else:raise ValueError(k)
    return s
sources={k:primitive(k) for k in ['box','sphere','cylinder','cone','crystal']}
mappers={}
for k,src in sources.items():
    m=vtk.vtkPolyDataMapper();m.SetInputConnection(src.GetOutputPort());mappers[k]=m

# Original tiling textures are present in the same Godot assets folder.
textures={}
texture_mappers={}
def for_actor_mapper(k,part):
    texname=part.get('tex','')
    if not texname or k not in ('box','cylinder'):
        return mappers[k],None
    if texname not in textures:
        rd=vtk.vtkPNGReader();rd.SetFileName(str(ROOT/'assets'/(texname+'.png')));rd.Update()
        texture=vtk.vtkTexture();texture.SetInputConnection(rd.GetOutputPort());texture.InterpolateOn();texture.RepeatOn()
        textures[texname]=(texture,rd)
    size=part['size']
    u=min(44,max(1,round(max(size[0],size[2])/2.2,1)))
    v=min(52,max(1,round(max(size[1],size[2])/2.2,1)))
    key=(k,u,v)
    if key not in texture_mappers:
        coords=vtk.vtkTransformTextureCoords()
        coords.SetInputConnection(sources[k].GetOutputPort())
        coords.SetScale(u,v,1)
        coords.Update()
        mapper=vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(coords.GetOutputPort())
        texture_mappers[key]=(coords,mapper)
    return texture_mappers[key][1],textures[texname][0]

# Repeatable transforms: from the same data fed into Godot.
def actor(part,house_pos=(0,0,0),house_yaw=0):
    k=part['kind'];a=vtk.vtkActor();mp,texture=for_actor_mapper(k,part);a.SetMapper(mp);color=col(part['color'])
    if texture is not None:a.SetTexture(texture)
    a.GetProperty().SetColor(*color)
    a.GetProperty().SetAmbient(.27)
    a.GetProperty().SetDiffuse(.78)
    a.GetProperty().SetSpecular(.10)
    a.GetProperty().SetSpecularPower(20)
    if part.get('emissive'):
        a.GetProperty().SetAmbient(.65)
        a.GetProperty().SetDiffuse(.53)
    rot=part.get('rot',[0,0,0]);dims=part['size']
    M=T(house_pos) @ R_axis(house_yaw,'y') @ T(part['at']) @ R_axis(rot[1],'y') @ R_axis(rot[0],'x') @ R_axis(rot[2],'z') @ S(dims)
    vm=vtk.vtkMatrix4x4()
    for i in range(4):
        for j in range(4):vm.SetElement(i,j,float(M[i,j]))
    a.SetUserMatrix(vm)
    renderer.AddActor(a)
    return a

for p in DATA['world_parts']:actor(p)
roof_actors={}
for h in DATA['buildings']:
    for p in h['parts']:
        a=actor(p,h['at'],h['yaw'])
        if p.get('roof'):
            roof_actors.setdefault(h['id'],[]).append(a)
# add minimal hero volumes from the original prototype so proportions read well
hero=(0,0,25.0)
for p in [
 {'kind':'box','at':[0,1.25,0],'size':[.82,.86,.55],'color':'#3a5362'},
 {'kind':'sphere','at':[0,1.91,0],'size':[.50,.47,.50],'color':'#b49a7c'},
 {'kind':'box','at':[-.54,1.22,0],'size':[.24,.89,.35],'color':'#6b7475'},
 {'kind':'box','at':[.54,1.22,0],'size':[.24,.89,.35],'color':'#6b7475'},
 {'kind':'box','at':[-.22,.5,0],'size':[.33,.95,.36],'color':'#414a4c'},
 {'kind':'box','at':[.22,.5,0],'size':[.33,.95,.36],'color':'#414a4c'},
 {'kind':'box','at':[0,1.0,.33],'size':[.75,1.3,.11],'color':'#476178'},
]:actor(p,hero)

window=vtk.vtkRenderWindow()
window.SetOffScreenRendering(1)
window.SetSize(1600,900)
window.SetMultiSamples(8)
window.AddRenderer(renderer)
camera=renderer.GetActiveCamera()

font_regular='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
font_bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'

def render(name,pos,focal,angle,labels=None):
    camera.SetPosition(*pos)
    camera.SetFocalPoint(*focal)
    camera.SetViewUp(0,1,0)
    camera.SetViewAngle(angle)
    renderer.ResetCameraClippingRange()
    window.Render()
    w2i=vtk.vtkWindowToImageFilter();w2i.SetInput(window);w2i.ReadFrontBufferOff();w2i.Update()
    writer=vtk.vtkPNGWriter();writer.SetInputConnection(w2i.GetOutputPort());writer.SetFileName(str(ROOT/name));writer.Write()
    img=Image.open(ROOT/name).convert('RGB')
    # layout belongs to the *project*, do not claim this is live engine footage
    over=Image.new('RGBA',img.size);draw=ImageDraw.Draw(over)
    f=ImageFont.truetype(font_bold,24)
    small=ImageFont.truetype(font_regular,17)
    title='AETHERFALL  /  STREET KIT v0.3'
    draw.rounded_rectangle((27,20,552,90),radius=10,fill=(20,27,32,190),outline=(153,143,124,190),width=2)
    draw.text((44,32),title,font=f,fill=(232,222,200,255))
    draw.text((45,64),'Рендер геометрии · не скриншот Godot',font=small,fill=(205,206,197,255))
    if labels:
        for title,place in labels:
            v=vtk.vtkCoordinate();v.SetCoordinateSystemToWorld();v.SetValue(*place)
            x,y=v.GetComputedDisplayValue(renderer)
            y=900-y
            if x<75 or x>1525 or y<110 or y>800:continue
            tw=draw.textbbox((0,0),title,font=f)[2]
            xx=int(x-tw/2)
            draw.rounded_rectangle((xx-13,y-42,xx+tw+13,y-3),radius=6,fill=(22,29,34,207),outline=(168,145,98,200),width=2)
            draw.text((xx,int(y-37)),title,font=f,fill=(246,235,211,255))
    Image.alpha_composite(img.convert('RGBA'),over).convert('RGB').save(ROOT/name,quality=95)
    print('Rendered',ROOT/name)

render('preview_street_play_view.jpg', (0,8.8,35), (0,2.5,-5), 63, [('ТАВЕРНА',(-10,5.7,11)),('КУЗНИЦА',(10,5.8,-7)),('МАГИЧЕСКАЯ ЛАВКА',(-10,5.7,-27))])
render('preview_street_overview.jpg', (28,35,32), (0,1.8,-5), 66, [('ТАВЕРНА',(-10,6,11)),('КУЗНИЦА',(10,6,-7)),('МАГИЧЕСКАЯ ЛАВКА',(-10,6,-27))])

# Entrance/interior view: simulate the same roof-alpha rule used in Godot.
for roof_actor in roof_actors['tavern']:
    roof_actor.GetProperty().SetOpacity(0.09)
render('preview_tavern_inside.jpg',(0,13,21),(-10,1.0,11),48,[('ТАВЕРНА · КРЫША ПРОЗРАЧНА',(-10,6.8,11))])
