"""Generate original compact 256x256 tiling color-neutral textures for the street kit.
Needs Pillow; PNGs are already included, so Godot does not need Python.
"""
from PIL import Image, ImageDraw, ImageFilter
from pathlib import Path
import random,math
r=random.Random(1310)
out=Path(__file__).resolve().parents[1]/'assets'
out.mkdir(exist_ok=True)
N=256

def tile(name,func):
    im=Image.new('RGB',(N,N),(180,180,180)); d=ImageDraw.Draw(im); func(im,d)
    im.save(out/(name+'.png'),optimize=True)

def cobble(im,d):
    d.rectangle((0,0,255,255),fill=(97,96,87))
    for row in range(10):
        y0=row*26
        x=-27+(13 if row%2 else 0)
        while x<257:
            x1=x+r.randint(21,31)
            value=r.randint(159,212)
            col=(value, value-4, value-12)
            d.rounded_rectangle((x+2,y0+2,x1-1,y0+23),radius=3, fill=col)
            d.line((x+4,y0+5,x1-4,y0+4), fill=(min(value+16,255),)*3,width=1)
            x=x1

def slate(im,d):
    d.rectangle((0,0,255,255),fill=(97,103,108))
    for row in range(16):
        y=row*16; x=-28+(14 if row%2 else 0)
        while x<256:
            x1=x+28
            val=r.randint(112,169)
            d.rectangle((x+1,y+1,x1-1,y+15), fill=(val,val+3,val+6))
            d.line((x+2,y+1,x1-2,y+1),fill=(min(val+17,255),)*3,width=1)
            x=x1

def plaster(im,d):
    px=im.load()
    for y in range(256):
        for x in range(256):
            v=int(194+10*math.sin(x*.038+y*.071)+r.randrange(-16,17))
            px[x,y]=(v,max(v-3,0),max(v-8,0))
    for i in range(28):
        x=r.randrange(256);y=r.randrange(256);v=r.randrange(125,173)
        d.line((x,y,x+r.randrange(-7,7),y+r.randrange(-3,3)),fill=(v,v,v),width=1)

def stone(im,d):
    d.rectangle((0,0,255,255),fill=(132,133,126))
    for j in range(10):
        y=j*26;x=-30+(r.randrange(-10,10))
        while x<256:
            x1=x+r.randrange(30,60);v=r.randrange(160,199)
            d.rounded_rectangle((x+2,y+2,x1-2,y+24),radius=2,fill=(v,v,max(0,v-7)))
            x=x1

def wood(im,d):
    d.rectangle((0,0,255,255),fill=(120,103,83))
    for i in range(17):
        y=i*15;v=r.randrange(121,185)
        d.rectangle((0,y+1,255,y+13),fill=(v,min(v+1,255),max(0,v-13)))
        d.line((0,y+3,255,y+3),fill=(min(255,v+18),min(255,v+12),v),width=1)
        for j in range(3):
            xx=r.randrange(255)
            d.line((xx,y+r.randrange(5,12),min(xx+30,255),y+r.randrange(5,12)),fill=(max(0,v-22),)*3,width=1)

def grass(im,d):
    px=im.load()
    for y in range(256):
        for x in range(256):
            v=int(177+12*math.sin(x*.11+y*.07)+r.randrange(-22,23));px[x,y]=(v, min(v+8,255),max(v-26,0))
    for i in range(190):
        x=r.randrange(256);y=r.randrange(256);d.line((x,y,x+r.randrange(-3,4),y-r.randrange(2,8)),fill=(r.randrange(115,170),r.randrange(145,195),r.randrange(99,153)),width=1)

def dirt(im,d):
    px=im.load()
    for y in range(256):
        for x in range(256):
            v=175+r.randrange(-22,23);px[x,y]=(v, v-7,v-21)
    for i in range(430):
        x=r.randrange(256);y=r.randrange(256);v=r.randrange(90,165)
        d.ellipse((x,y,x+r.randrange(1,4),y+r.randrange(1,3)),fill=(v,v-5,max(0,v-14)))

def glass(im,d):
    d.rectangle((0,0,255,255),fill=(255,233,185))
    for x in range(0,256,32):d.line((x,0,x+40,255),fill=(248,222,177),width=3)

def cloth(im,d):
    d.rectangle((0,0,255,255), fill=(192,196,201))
    for x in range(0,256,6):d.line((x,0,x,255),fill=(187,191,197),width=1)
for k,fun in [('cobble',cobble),('slate',slate),('plaster',plaster),('stone',stone),('wood',wood),('grass',grass),('dirt',dirt),('glass',glass),('cloth',cloth)]:tile(k,fun)
print('wrote',len(list(out.glob('*.png'))),'tiling textures')
