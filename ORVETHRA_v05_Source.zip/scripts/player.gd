extends CharacterBody3D
class_name AetherPlayer

signal dealt_damage(mob: AetherMob, damage: int)
signal died()
signal changed()

const MOVE_SPEED: float = 6.1
const JUMP_SPEED: float = 7.0
var level: int = 1
var experience: int = 0
var max_health: int = 125
var health: int = 125
var max_mana: int = 90
var mana: int = 90
var target: AetherMob
var touch_move: Vector2 = Vector2.ZERO
var auto_attack: bool = false
var swing_wait: float = 0.0
var skill_wait: float = 0.0
var heal_wait: float = 0.0
var camera_yaw: float = 0.0
var camera_pitch: float = -0.24
var camera_distance: float = 7.5
var look_touch_id: int = -1
var old_touch: Vector2 = Vector2.ZERO
var visual: Node3D
var left_leg: MeshInstance3D
var right_leg: MeshInstance3D
var left_arm: MeshInstance3D
var right_arm: MeshInstance3D
var anim_time: float = 0.0
var view: Camera3D
var rig: Node3D
var death_lock: float = 0.0

func _ready() -> void:
 name = "Traveler"
 collision_layer = 2
 collision_mask = 1
 var collider := CollisionShape3D.new()
 var capsule := CapsuleShape3D.new()
 capsule.height = 2.0
 capsule.radius = 0.36
 collider.shape = capsule
 collider.position.y = 1.0
 add_child(collider)
 visual = Node3D.new()
 add_child(visual)
 _part(Vector3(0, 1.33, 0), Vector3(0.80, 0.91, 0.48), Color("435666"))
 _part(Vector3(0, 1.95, 0), Vector3(0.44, 0.47, 0.42), Color("bd9d82"))
 _part(Vector3(0, 2.27, -0.025), Vector3(0.57, 0.17, 0.58), Color("383c42"))
 _part(Vector3(0, 1.22, 0.29), Vector3(0.32, 0.37, 0.08), Color("c1a36c"))
 left_arm = _part(Vector3(-0.54, 1.31, 0), Vector3(0.31, 0.86, 0.38), Color("6d7776"))
 right_arm = _part(Vector3(0.54, 1.31, 0), Vector3(0.31, 0.86, 0.38), Color("6d7776"))
 left_leg = _part(Vector3(-0.21, 0.47, 0), Vector3(0.30, 0.88, 0.40), Color("333d42"))
 right_leg = _part(Vector3(0.21, 0.47, 0), Vector3(0.30, 0.88, 0.40), Color("333d42"))
 # Dark cloth cape makes the silhouette readable at mobile resolutions.
 _part(Vector3(0, 1.17, 0.30), Vector3(0.76, 1.42, 0.10), Color("354753"))
 rig = Node3D.new()
 rig.position.y = 1.68
 add_child(rig)
 view = Camera3D.new()
 view.current = true
 view.fov = 66.0
 view.near = 0.15
 rig.add_child(view)
 Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if not OS.has_feature("mobile") else Input.MOUSE_MODE_VISIBLE

func _part(at: Vector3, dimensions: Vector3, tint: Color) -> MeshInstance3D:
 var node := MeshInstance3D.new()
 var mesh := BoxMesh.new()
 mesh.size = dimensions
 node.mesh = mesh
 node.position = at
 var material := StandardMaterial3D.new()
 material.albedo_color = tint
 material.roughness = 0.88
 node.material_override = material
 visual.add_child(node)
 return node

func _unhandled_input(event: InputEvent) -> void:
 if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
  camera_yaw -= event.relative.x * 0.003
  camera_pitch = clampf(camera_pitch - event.relative.y * 0.003, -0.9, 0.25)
 elif event is InputEventMouseButton and event.pressed:
  if event.button_index == MOUSE_BUTTON_WHEEL_UP:
   camera_distance = maxf(3.5, camera_distance - 0.7)
  elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
   camera_distance = minf(12.0, camera_distance + 0.7)
 elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
  Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED else Input.MOUSE_MODE_CAPTURED
 elif event is InputEventScreenTouch:
  if event.pressed and event.position.x > get_viewport().get_visible_rect().size.x * 0.45 and look_touch_id < 0:
   look_touch_id = event.index
   old_touch = event.position
  elif not event.pressed and event.index == look_touch_id:
   look_touch_id = -1
 elif event is InputEventScreenDrag and event.index == look_touch_id:
  var difference: Vector2 = event.position - old_touch
  camera_yaw -= difference.x * 0.005
  camera_pitch = clampf(camera_pitch - difference.y * 0.005, -0.9, 0.25)
  old_touch = event.position

func _physics_process(delta: float) -> void:
 swing_wait = maxf(0.0, swing_wait - delta)
 skill_wait = maxf(0.0, skill_wait - delta)
 heal_wait = maxf(0.0, heal_wait - delta)
 if health <= 0:
  death_lock -= delta
  if death_lock <= 0.0:
   health = max_health
   mana = max_mana
   global_position = Vector3(0, 0.2, 16)
   changed.emit()
  return
 var input_axis: Vector2 = Input.get_vector("move_left", "move_right", "move_forward", "move_backward")
 if touch_move.length() > 0.06:
  input_axis = touch_move
 var right: Vector3 = Vector3(cos(camera_yaw), 0, -sin(camera_yaw))
 var forward: Vector3 = Vector3(-sin(camera_yaw), 0, -cos(camera_yaw))
 var direction: Vector3 = right * input_axis.x - forward * input_axis.y
 direction = direction.limit_length(1.0)
 velocity.x = direction.x * MOVE_SPEED
 velocity.z = direction.z * MOVE_SPEED
 if not is_on_floor():
  velocity.y -= 24.0 * delta
 elif Input.is_action_just_pressed("jump"):
  velocity.y = JUMP_SPEED
 else:
  velocity.y = -0.3
 move_and_slide()
 if direction.length() > 0.1:
  visual.rotation.y = lerp_angle(visual.rotation.y, atan2(-direction.x, -direction.z), delta * 12.0)
 anim_time += delta * (9.0 if direction.length() > 0.1 else 2.0)
 var swing: float = sin(anim_time) * (0.40 if direction.length() > 0.1 else 0.025)
 left_leg.rotation.x = swing
 right_leg.rotation.x = -swing
 left_arm.rotation.x = -swing * 0.65
 right_arm.rotation.x = swing * 0.65
 rig.rotation.y = camera_yaw
 view.position = Vector3(0, -sin(camera_pitch) * camera_distance, cos(camera_pitch) * camera_distance)
 view.look_at(rig.to_global(Vector3(0, 0.28, 0)), Vector3.UP)
 if auto_attack and is_instance_valid(target) and target.active and swing_wait <= 0.0:
  basic_attack()
 if Input.is_action_just_pressed("attack"):
  toggle_autoattack()
 if Input.is_action_just_pressed("strong_attack"):
  heavy_attack()
 if Input.is_action_just_pressed("heal"):
  self_heal()

func set_target(mob: AetherMob) -> void:
 target = mob
 auto_attack = false

func toggle_autoattack() -> void:
 auto_attack = not auto_attack
 if auto_attack:
  basic_attack()

func basic_attack() -> bool:
 if swing_wait > 0.0 or health <= 0:
  return false
 swing_wait = 1.05
 if is_instance_valid(target) and target.active and global_position.distance_to(target.global_position) < 4.0:
  dealt_damage.emit(target, 15 + level * 3)
  return true
 return false

func heavy_attack() -> bool:
 if skill_wait > 0.0 or mana < 18 or health <= 0:
  return false
 if not is_instance_valid(target) or not target.active or global_position.distance_to(target.global_position) > 5.5:
  return false
 mana -= 18
 skill_wait = 4.5
 dealt_damage.emit(target, 31 + level * 5)
 changed.emit()
 return true

func self_heal() -> bool:
 if heal_wait > 0.0 or mana < 22 or health >= max_health:
  return false
 mana -= 22
 heal_wait = 9.0
 health = mini(max_health, health + 39 + level * 4)
 changed.emit()
 return true

func take_damage(amount: int) -> void:
 if health <= 0:
  return
 health = maxi(0, health - amount)
 changed.emit()
 if health <= 0:
  auto_attack = false
  death_lock = 3.5
  died.emit()

func restore_from_potion() -> void:
 health = mini(max_health, health + 70)
 changed.emit()

func gain_experience(amount: int) -> bool:
 experience += amount
 var level_up: bool = false
 while experience >= exp_to_next():
  experience -= exp_to_next()
  level += 1
  max_health += 19
  max_mana += 10
  health = max_health
  mana = max_mana
  level_up = true
 changed.emit()
 return level_up

func exp_to_next() -> int:
 return 75 + (level - 1) * 62
