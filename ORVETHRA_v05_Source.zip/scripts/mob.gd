extends Node3D
class_name AetherMob

signal defeated(mob: AetherMob)
signal hurt(mob: AetherMob, value: int)

var display_name: String = ""
var kind: String = "wolf"
var level: int = 2
var max_health: int = 60
var health: int = 60
var xp_reward: int = 15
var elite: bool = false
var active: bool = true
var spawn_point: Vector3
var hero: AetherPlayer
var hit_timer: float = 0.0
var respawn_timer: float = 0.0
var walk_phase: float = 0.0
var move_speed: float = 1.7
var graphic: Node3D
var targeting_ring: MeshInstance3D

func setup(world, mob_kind: String, mob_level: int, at: Vector3, is_elite: bool = false) -> void:
 kind = mob_kind
 level = mob_level
 elite = is_elite
 position = at
 spawn_point = at
 display_name = ("Каменный страж" if elite else ("Лесной волк" if kind == "wolf" else "Дикий кабан" if kind == "boar" else "Лунный слизень"))
 max_health = (280 if elite else 55 + level * 12)
 health = max_health
 xp_reward = (115 if elite else 14 + level * 6)
 move_speed = (1.1 if elite else 1.5 + float(level) * 0.08)
 graphic = Node3D.new()
 add_child(graphic)
 var fur: Material = world.material(Color("6f6c65") if kind == "wolf" else Color("796351") if kind == "boar" else Color("587f8b"))
 var eyes: Material = world.glow_material(Color("a9b9b1") if not elite else Color("8da6d2"))
 if kind == "slime":
  world.sphere_part(graphic, Vector3(0, 0.65, 0), Vector3(0.82, 0.62, 0.76), fur)
  world.box_part(graphic, Vector3(-0.22, 0.78, -0.65), Vector3(0.12, 0.10, 0.06), eyes)
  world.box_part(graphic, Vector3(0.22, 0.78, -0.65), Vector3(0.12, 0.10, 0.06), eyes)
 elif elite:
  world.box_part(graphic, Vector3(0, 1.35, 0), Vector3(1.8, 2.3, 1.55), fur)
  world.box_part(graphic, Vector3(0, 2.95, 0), Vector3(1.2, 1.0, 1.2), world.material(Color("727c7a")))
  world.box_part(graphic, Vector3(-1.1, 1.4, 0), Vector3(0.65, 1.75, 0.75), fur)
  world.box_part(graphic, Vector3(1.1, 1.4, 0), Vector3(0.65, 1.75, 0.75), fur)
  world.box_part(graphic, Vector3(0, 1.9, -0.83), Vector3(0.76, 0.86, 0.16), eyes)
 else:
  world.box_part(graphic, Vector3(0, 0.85, 0), Vector3(0.86, 0.8, 1.48), fur)
  world.box_part(graphic, Vector3(0, 1.13, -0.76), Vector3(0.68, 0.61, 0.7), fur)
  for x in [-0.32, 0.32]:
   for z in [-0.45, 0.48]:
    world.box_part(graphic, Vector3(x, 0.36, z), Vector3(0.24, 0.71, 0.26), fur)
   world.box_part(graphic, Vector3(x * 0.66, 1.25, -1.13), Vector3(0.10, 0.12, 0.08), eyes)
 var ring := MeshInstance3D.new()
 var ring_mesh := TorusMesh.new()
 ring_mesh.inner_radius = 0.97 if elite else 0.65
 ring_mesh.outer_radius = 1.04 if elite else 0.70
 ring.mesh = ring_mesh
 ring.position.y = 0.08
 ring.material_override = world.glow_material(Color("b8a75d"))
 ring.visible = false
 add_child(ring)
 targeting_ring = ring

func _process(delta: float) -> void:
 if not active:
  respawn_timer -= delta
  if respawn_timer <= 0.0:
   active = true
   visible = true
   health = max_health
   position = spawn_point
  return
 walk_phase += delta * 3.5
 if graphic != null:
  graphic.position.y = sin(walk_phase) * 0.035
 if hero == null or hero.health <= 0.0:
  return
 hit_timer = maxf(0.0, hit_timer - delta)
 var distance: float = global_position.distance_to(hero.global_position)
 if distance < (13.0 if elite else 8.0) and distance > 1.65 and global_position.distance_to(spawn_point) < 18.0:
  var vec: Vector3 = hero.global_position - global_position
  vec.y = 0.0
  if vec.length() > 0.01:
   position += vec.normalized() * move_speed * delta
   graphic.rotation.y = lerp_angle(graphic.rotation.y, atan2(-vec.x, -vec.z), delta * 5.0)
 elif global_position.distance_to(spawn_point) > 2.0 and distance > 18.0:
  var home: Vector3 = (spawn_point - global_position).normalized()
  position += home * move_speed * delta
 if distance < 2.1 and hit_timer <= 0.0:
  hit_timer = 1.65
  hero.take_damage(11 if elite else 3 + level)

func receive_hit(damage: int) -> void:
 if not active:
  return
 health = maxi(0, health - damage)
 hurt.emit(self, damage)
 if health <= 0:
  active = false
  visible = false
  respawn_timer = 25.0 if elite else 15.0
  defeated.emit(self)

func capture() -> void:
 if not active:
  return
 active = false
 visible = false
 respawn_timer = 20.0

func set_selected(is_selected: bool) -> void:
 if targeting_ring != null:
  targeting_ring.visible = is_selected and active
