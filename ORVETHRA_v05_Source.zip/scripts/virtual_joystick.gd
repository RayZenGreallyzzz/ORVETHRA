extends Control
class_name AetherVirtualJoystick

signal direction_changed(vec: Vector2)
var finger: int = -1
var axis: Vector2 = Vector2.ZERO
var radius: float = 54.0

func _ready() -> void:
 custom_minimum_size = Vector2(174, 174)
 mouse_filter = Control.MOUSE_FILTER_STOP
 queue_redraw()

func _gui_input(event: InputEvent) -> void:
 if event is InputEventScreenTouch:
  if event.pressed and finger < 0:
   finger = event.index
   _update_axis(event.position)
   accept_event()
  elif not event.pressed and event.index == finger:
   finger = -1
   axis = Vector2.ZERO
   direction_changed.emit(axis)
   queue_redraw()
   accept_event()
 elif event is InputEventScreenDrag and event.index == finger:
  _update_axis(event.position)
  accept_event()
 elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
  if event.pressed:
   finger = 999
   _update_axis(event.position)
  elif finger == 999:
   finger = -1
   axis = Vector2.ZERO
   direction_changed.emit(axis)
   queue_redraw()
 elif event is InputEventMouseMotion and finger == 999:
  _update_axis(event.position)

func _update_axis(pointer: Vector2) -> void:
 axis = ((pointer - size * 0.5) / radius).limit_length(1.0)
 direction_changed.emit(axis)
 queue_redraw()

func _draw() -> void:
 var center: Vector2 = size * 0.5
 draw_circle(center, 72.0, Color(0.12, 0.18, 0.20, 0.28))
 draw_arc(center, 66.0, 0.0, TAU, 56, Color(0.65, 0.65, 0.54, 0.58), 2.0, true)
 draw_circle(center + axis * radius, 30.0, Color(0.58, 0.62, 0.59, 0.48))
 draw_arc(center + axis * radius, 30.0, 0.0, TAU, 36, Color(0.92, 0.79, 0.54, 0.67), 1.5, true)
