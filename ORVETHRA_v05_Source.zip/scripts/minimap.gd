extends Control
class_name AetherMinimap

var hero: AetherPlayer
var enemies: Array[AetherMob] = []
var world_scale: float = 1.0

func _ready() -> void:
 mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(_delta: float) -> void:
 queue_redraw()

func _draw() -> void:
 var center: Vector2 = size * 0.5
 var radius: float = minf(size.x, size.y) * 0.44
 draw_circle(center, radius + 6.0, Color("3c403b"))
 draw_circle(center, radius, Color("657b65"))
 draw_arc(center, radius + 4.0, 0, TAU, 64, Color("c0ae85"), 3.0, true)
 # Top-down stylized world: city stone on the south side, open fields north.
 if hero != null:
  var offset_city: Vector2 = Vector2(-hero.global_position.x, 48.0 - hero.global_position.z) * 0.31
  if offset_city.length() < radius - 12:
   draw_circle(center + Vector2(offset_city.x, -offset_city.y), 11.0, Color("b4ad9a"))
  for m in enemies:
   if not is_instance_valid(m) or not m.active:
    continue
   var diff: Vector2 = Vector2(m.global_position.x - hero.global_position.x, m.global_position.z - hero.global_position.z) * 0.31
   if diff.length() < radius - 6:
    draw_circle(center + Vector2(diff.x, diff.y), 3.0 if not m.elite else 5.0, Color("a34b43") if not m.elite else Color("dbb966"))
 draw_circle(center, 5.0, Color("d8e6d9"))
 draw_line(center + Vector2(0, -10), center + Vector2(0, -2), Color("f4d59b"), 2.0)
