extends Node3D
class_name AetherPet

signal struck(mob: AetherMob, damage: int)
var owner_player: AetherPlayer
var pet_level: int = 1
var pet_experience: int = 0
var attack_timer: float = 0.0
var body_visual: Node3D
var current_mob: AetherMob

func build(world) -> void:
 body_visual = Node3D.new()
 add_child(body_visual)
 var fur: Material = world.material(Color("756b60"))
 var mane: Material = world.material(Color("454e51"))
 world.box_part(body_visual, Vector3(0, 0.80, 0), Vector3(0.75, 0.63, 1.35), fur)
 world.box_part(body_visual, Vector3(0, 1.02, -0.72), Vector3(0.70, 0.60, 0.65), mane)
 for x in [-0.28, 0.28]:
  for z in [-0.45, 0.43]:
   world.box_part(body_visual, Vector3(x, 0.37, z), Vector3(0.22, 0.68, 0.22), fur)
  world.box_part(body_visual, Vector3(x, 1.13, -1.05), Vector3(0.14, 0.11, 0.08), world.glow_material(Color("b5b7aa")))

func _process(delta: float) -> void:
 if owner_player == null or owner_player.health <= 0:
  return
 attack_timer = maxf(0.0, attack_timer - delta)
 var trailing: Vector3 = owner_player.global_position + Vector3(1.65, 0, 1.65).rotated(Vector3.UP, owner_player.camera_yaw)
 var distance: float = global_position.distance_to(trailing)
 if distance > 24.0:
  global_position = trailing
 elif distance > 1.1:
  var direction: Vector3 = (trailing - global_position).normalized()
  global_position += direction * minf(delta * 5.6, distance)
  body_visual.rotation.y = lerp_angle(body_visual.rotation.y, atan2(-direction.x, -direction.z), delta * 9.0)
 if is_instance_valid(current_mob) and current_mob.active and global_position.distance_to(current_mob.global_position) < 6.0:
  if attack_timer <= 0.0:
   attack_timer = 1.55
   struck.emit(current_mob, 7 + pet_level * 3)

func gain_experience(value: int) -> bool:
 pet_experience += value
 if pet_experience >= 60 + pet_level * 40:
  pet_experience -= 60 + pet_level * 40
  pet_level += 1
  return true
 return false
