extends Node3D

# AETHERFALL FIRST PLAYABLE / v0.2
# Procedural, original offline MMORPG-style vertical slice. No external assets.
const PLAYER_SCENE = preload("res://scripts/player.gd")
const MOB_SCENE = preload("res://scripts/mob.gd")
const PET_SCENE = preload("res://scripts/pet.gd")
const HOUSE_SCENE = preload("res://scripts/house.gd")
const JOYSTICK_SCENE = preload("res://scripts/virtual_joystick.gd")
const MINIMAP_SCENE = preload("res://scripts/minimap.gd")
const SAVE_PATH: String = "user://aetherfall_save_v02.json"

var mats: Dictionary = {}
var hero: AetherPlayer
var pet: AetherPet
var mobs: Array[AetherMob] = []
var houses: Array[AetherHouse] = []
var chosen: AetherMob
var rng := RandomNumberGenerator.new()
var world_sun: DirectionalLight3D
var inventory: Dictionary = {"potion": 3, "card": 2, "gold": 0}
var pet_unlocked: bool = false
var pet_level_saved: int = 1
var pet_xp_saved: int = 0
var last_message: String = "Добро пожаловать в долину. За воротами начинаются приключения."
var message_timer: float = 0.0
var save_timer: float = 30.0
var hp_bar: ProgressBar
var mp_bar: ProgressBar
var exp_bar: ProgressBar
var name_label: Label
var pet_label: Label
var target_label: Label
var status_label: Label
var message_label: Label
var backpack_label: Label
var pet_frame: PanelContainer
var target_frame: PanelContainer
var backpack_frame: PanelContainer
var attack_button: Button
var compass: AetherMinimap
var quality: int = -1
var foliage_instances: Array[GeometryInstance3D] = []
var day_clock: float = 0.0

func _ready() -> void:
 rng.seed = 20261012
 _prepare_lighting()
 _create_terrain()
 _build_city()
 _build_wilderness()
 hero = PLAYER_SCENE.new() as AetherPlayer
 hero.position = Vector3(0, 0.2, 18.0)
 add_child(hero)
 hero.dealt_damage.connect(_hero_hit)
 hero.died.connect(func() -> void: info("Вы потеряли силы. Возрождение у городских ворот через 3 сек."))
 _create_enemies()
 _interface()
 _load_save()
 _set_quality(1)
 info("Tab — выбрать цель · 1 — автоатака · 2 — удар · 3 — лечение · T — приручить")

func material(c: Color) -> StandardMaterial3D:
 var key: String = c.to_html()
 if mats.has(key):
  return mats[key] as StandardMaterial3D
 var mat := StandardMaterial3D.new()
 mat.albedo_color = c
 mat.roughness = 0.92
 mats[key] = mat
 return mat

func glow_material(c: Color) -> StandardMaterial3D:
 var mat := StandardMaterial3D.new()
 mat.albedo_color = c
 mat.emission_enabled = true
 mat.emission = c
 mat.emission_energy_multiplier = 1.15
 mat.roughness = 0.45
 return mat

func box_part(parent: Node3D, at: Vector3, dimensions: Vector3, mat: Material, solid: bool = false) -> MeshInstance3D:
 var cube := MeshInstance3D.new()
 var mesh := BoxMesh.new()
 mesh.size = dimensions
 cube.mesh = mesh
 cube.material_override = mat
 cube.position = at
 parent.add_child(cube)
 if solid:
  var physics := StaticBody3D.new()
  physics.position = at
  physics.collision_layer = 1
  var shape := CollisionShape3D.new()
  var box := BoxShape3D.new()
  box.size = dimensions
  shape.shape = box
  physics.add_child(shape)
  parent.add_child(physics)
 return cube

func sphere_part(parent: Node3D, at: Vector3, dimensions: Vector3, mat: Material) -> MeshInstance3D:
 var node := MeshInstance3D.new()
 var mesh := SphereMesh.new()
 mesh.radius = 0.5
 mesh.height = 1.0
 mesh.radial_segments = 10
 mesh.rings = 5
 node.mesh = mesh
 node.scale = dimensions * 2.0
 node.position = at
 node.material_override = mat
 parent.add_child(node)
 return node

func cylinder_part(parent: Node3D, at: Vector3, radius: float, length: float, mat: Material) -> MeshInstance3D:
 var cylinder := MeshInstance3D.new()
 var mesh := CylinderMesh.new()
 mesh.top_radius = radius
 mesh.bottom_radius = radius
 mesh.height = length
 mesh.radial_segments = 12
 cylinder.mesh = mesh
 cylinder.material_override = mat
 cylinder.position = at
 parent.add_child(cylinder)
 return cylinder

func _prepare_lighting() -> void:
 var sky_environment := WorldEnvironment.new()
 var env := Environment.new()
 env.background_mode = Environment.BG_COLOR
 env.background_color = Color("aeb8b8")
 env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
 env.ambient_light_color = Color("adb6ac")
 env.ambient_light_energy = 0.60
 env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
 env.fog_enabled = true
 env.fog_light_color = Color("b8b8ad")
 env.fog_density = 0.009
 sky_environment.environment = env
 add_child(sky_environment)
 world_sun = DirectionalLight3D.new()
 world_sun.rotation_degrees = Vector3(-53, -22, 0)
 world_sun.light_color = Color("e8d9b7")
 world_sun.light_energy = 1.10
 world_sun.shadow_enabled = true
 world_sun.directional_shadow_max_distance = 65.0
 add_child(world_sun)

func _create_terrain() -> void:
 box_part(self, Vector3(0, -0.62, -50), Vector3(390, 1.24, 390), material(Color("71806b")), true)
 # Cobblestone plaza around the crystal and a weathered dirt road to the plains.
 box_part(self, Vector3(0, 0.025, 51), Vector3(43.5, 0.055, 65.0), material(Color("aca798")))
 box_part(self, Vector3(0, 0.038, -71), Vector3(9.6, 0.055, 230), material(Color("927f69")))
 box_part(self, Vector3(0, 0.042, 15), Vector3(9.3, 0.05, 30), material(Color("a89c87")))
 # Uneven crossing and streams. Water is a visual strip for this prototype.
 box_part(self, Vector3(73, 0.052, -95), Vector3(8.0, 0.07, 148.0), material(Color("718e93")))
 for i in range(24):
  var bx: float = rng.randf_range(-175.0, 175.0)
  var bz: float = rng.randf_range(-225.0, 100.0)
  if absf(bx) < 17.0 and bz > -180:
   continue
  var size: float = rng.randf_range(1.0, 4.2)
  var rock := box_part(self, Vector3(bx, size * 0.23, bz), Vector3(size, size * 0.55, size * 0.8), material(Color("797a72")))
  rock.rotation.y = rng.randf_range(-PI, PI)

func _roofed_house(pos: Vector3, yaw: float, wall_color: Color, roof_color: Color, shop: String) -> void:
 var home := HOUSE_SCENE.new() as AetherHouse
 home.position = pos
 home.rotation.y = yaw
 add_child(home)
 home.build(self, wall_color, roof_color, shop)
 houses.append(home)

func _build_city() -> void:
 var stone: Material = material(Color("85877e"))
 var dark: Material = material(Color("515e68"))
 var gold: Material = material(Color("b19a68"))
 # City walls leave a ten-metre-wide, unobstructed gateway facing the fields.
 box_part(self, Vector3(-28.0, 2.8, 11.5), Vector3(40.0, 5.6, 2.0), stone, true)
 box_part(self, Vector3(28.0, 2.8, 11.5), Vector3(40.0, 5.6, 2.0), stone, true)
 for x in [-8.0, 8.0]:
  box_part(self, Vector3(x, 4.1, 11.5), Vector3(4.4, 8.2, 4.8), stone, true)
  var roof := cylinder_part(self, Vector3(x, 8.6, 11.5), 2.9, 0.45, dark)
  roof.rotation.y = PI / 4.0
  box_part(self, Vector3(x, 5.4, 8.9), Vector3(1.0, 2.4, 0.08), dark)
  box_part(self, Vector3(x, 5.1, 8.78), Vector3(0.2, 0.5, 0.13), gold)
 for x in [-48.0, 48.0]:
  box_part(self, Vector3(x, 2.8, 55), Vector3(2, 5.6, 88.0), stone, true)
 box_part(self, Vector3(0, 2.8, 99), Vector3(98, 5.6, 2.0), stone, true)
 # Place a few reachable shops around the plaza, not behind inaccessible doors.
 _roofed_house(Vector3(-24, 0, 33), PI / 2.0, Color("b6ad9d"), Color("536a78"), "Кузница")
 _roofed_house(Vector3(24, 0, 33), -PI / 2.0, Color("c1b19b"), Color("6c6d71"), "Таверна")
 _roofed_house(Vector3(-24, 0, 57), PI / 2.0, Color("beb8a8"), Color("717c75"), "Склад")
 _roofed_house(Vector3(24, 0, 57), -PI / 2.0, Color("acaea6"), Color("4f6770"), "Лавка")
 _roofed_house(Vector3(-24, 0, 79), PI / 2.0, Color("b9b0a0"), Color("626d78"), "Гильдия")
 _roofed_house(Vector3(24, 0, 79), -PI / 2.0, Color("bfb5a4"), Color("73746b"), "Алхимия")
 # Central crystal fountain: muted blue/gray like a low-fantasy town, not neon.
 cylinder_part(self, Vector3(0, 0.20, 53.0), 3.8, 0.40, material(Color("8a8b82")))
 cylinder_part(self, Vector3(0, 0.43, 53.0), 2.9, 0.12, material(Color("647f82")))
 cylinder_part(self, Vector3(0, 1.0, 53.0), 0.57, 1.25, stone)
 var crystal := box_part(self, Vector3(0, 2.25, 53), Vector3(0.88, 1.95, 0.88), glow_material(Color("668d9c")))
 crystal.rotation.y = PI / 4.0
 crystal.rotation.z = 0.14
 for j in range(7):
  var theta: float = float(j) / 7.0 * TAU
  var p := Vector3(cos(theta) * 2.65, 0.65, 53.0 + sin(theta) * 2.65)
  box_part(self, p, Vector3(0.24, 1.05, 0.24), material(Color("9b9c92")))
 # Banners, market booths and sparse greenery.
 for i in range(9):
  var sign_x: float = -18.0 + float(i % 5) * 9.0
  var sign_z: float = 25.0 + float(i / 5) * 60.0
  cylinder_part(self, Vector3(sign_x, 1.5, sign_z), 0.10, 3.0, material(Color("746453")))
  box_part(self, Vector3(sign_x + 0.38, 2.6, sign_z), Vector3(0.8, 1.0, 0.07), dark)
 box_part(self, Vector3(-10, 1.00, 61), Vector3(2.4, 2.0, 1.3), material(Color("8b765a")))
 box_part(self, Vector3(-10, 2.20, 61), Vector3(3.2, 0.24, 2.2), material(Color("726b6c")))
 box_part(self, Vector3(10, 1.00, 61), Vector3(2.4, 2.0, 1.3), material(Color("8b765a")))
 box_part(self, Vector3(10, 2.20, 61), Vector3(3.2, 0.24, 2.2), dark)
 for x in [-37.0, 37.0]:
  for z in [28.0, 45.0, 66.0, 87.0]:
   cylinder_part(self, Vector3(x, 0.95, z), 0.38, 1.85, material(Color("7e6753")))
   sphere_part(self, Vector3(x, 2.15, z), Vector3(1.5, 1.7, 1.45), material(Color("687c65")))

func _build_wilderness() -> void:
 # Tree trunks and canopies are instanced to avoid hundreds of draw calls.
 var locations: Array[Vector3] = []
 for i in range(240):
  var x: float = rng.randf_range(-173.0, 173.0)
  var z: float = rng.randf_range(-231.0, 7.0)
  if absf(x) < 15.0 and z > -185:
   continue
  if absf(x - 73.0) < 9:
   continue
  locations.append(Vector3(x, 0, z))
 var bark := CylinderMesh.new()
 bark.top_radius = 0.24
 bark.bottom_radius = 0.33
 bark.height = 3.2
 bark.radial_segments = 6
 var bough := SphereMesh.new()
 bough.radius = 1.8
 bough.height = 3.3
 bough.radial_segments = 7
 bough.rings = 4
 _instanced(locations, bark, material(Color("625b4c")), Vector3(0, 1.6, 0), false)
 _instanced(locations, bough, material(Color("536f58")), Vector3(0, 4.1, 0), true)
 # Small grass tufts rendered in one MultiMesh, rather than separate meshes.
 var tufts: Array[Vector3] = []
 for i in range(830):
  var x: float = rng.randf_range(-173.0, 173.0)
  var z: float = rng.randf_range(-230.0, 8.0)
  if absf(x) < 5.0 or absf(x - 73.0) < 6.0:
   continue
  tufts.append(Vector3(x, 0.23, z))
 var blade := BoxMesh.new()
 blade.size = Vector3(0.13, 0.45, 0.12)
 _instanced(tufts, blade, material(Color("7f8d6b")), Vector3.ZERO, false)
 # One ancient stone arch marks the first exploration objective.
 var old_stone := material(Color("797e76"))
 for x in [-2.65, 2.65]:
  box_part(self, Vector3(x - 31.0, 2.3, -71.0), Vector3(1.45, 4.6, 1.45), old_stone)
 box_part(self, Vector3(-31, 4.75, -71), Vector3(6.8, 1.0, 1.4), old_stone)
 for i in range(6):
  box_part(self, Vector3(32 + float(i % 3) * 3.2, 0.75, -117 - float(i / 3) * 3.2), Vector3(1.5, 1.5, 1.8), old_stone)

func _instanced(places: Array[Vector3], primitive: Mesh, mat: Material, add_pos: Vector3, can_scale: bool) -> void:
 var multi := MultiMesh.new()
 multi.transform_format = MultiMesh.TRANSFORM_3D
 multi.mesh = primitive
 multi.instance_count = places.size()
 for i in range(places.size()):
  var size_factor: float = rng.randf_range(0.72, 1.30) if can_scale else 1.0
  var trans := Transform3D(Basis().scaled(Vector3.ONE * size_factor), places[i] + add_pos * size_factor)
  multi.set_instance_transform(i, trans)
 var mi := MultiMeshInstance3D.new()
 mi.multimesh = multi
 mi.material_override = mat
 add_child(mi)
 foliage_instances.append(mi)

func _create_enemies() -> void:
 var layout: Array[Dictionary] = [
  {"type":"slime", "lvl":1, "x":-5.0, "z":-23.0},
  {"type":"slime", "lvl":1, "x":7.0, "z":-32.0},
  {"type":"wolf", "lvl":2, "x":-12.0, "z":-46.0},
  {"type":"wolf", "lvl":2, "x":8.0, "z":-56.0},
  {"type":"boar", "lvl":3, "x":17.0, "z":-74.0},
  {"type":"boar", "lvl":3, "x":-17.0, "z":-87.0},
  {"type":"wolf", "lvl":4, "x":-22.0, "z":-98.0},
  {"type":"wolf", "lvl":4, "x":11.0, "z":-116.0},
  {"type":"boar", "lvl":5, "x":17.0, "z":-142.0},
  {"type":"slime", "lvl":5, "x":-11.0, "z":-150.0},
  {"type":"golem", "lvl":7, "x":-42.0, "z":-147.0, "elite":true}
 ]
 for setup_data in layout:
  var enemy := MOB_SCENE.new() as AetherMob
  add_child(enemy)
  enemy.setup(self, str(setup_data["type"]), int(setup_data["lvl"]), Vector3(float(setup_data["x"]), 0, float(setup_data["z"])), bool(setup_data.get("elite", false)))
  enemy.hero = hero
  enemy.defeated.connect(_mob_defeated)
  enemy.hurt.connect(_mob_hurt)
  mobs.append(enemy)

func _process(delta: float) -> void:
 day_clock += delta * 0.017
 world_sun.rotation.x = -0.95 + sin(day_clock) * 0.09
 save_timer -= delta
 if save_timer <= 0:
  _save_game()
  save_timer = 30.0
 for home in houses:
  home.update_for_player(hero.global_position, delta)
 message_timer = maxf(0.0, message_timer - delta)
 if message_timer <= 0.0 and message_label != null:
  message_label.text = "Выход из города: на север • Таблица умений: 1 / 2 / 3"
 if Input.is_action_just_pressed("select_target"):
  _select_nearest()
 if Input.is_action_just_pressed("summon_pet"):
  _toggle_pet()
 if Input.is_action_just_pressed("tame"):
  _try_tame()
 if Input.is_action_just_pressed("use_potion"):
  _drink_potion()
 if Input.is_action_just_pressed("inventory"):
  _toggle_backpack()
 if Input.is_action_just_pressed("quick_save"):
  _save_game()
  info("Сохранено!")
 if Input.is_key_pressed(KEY_F1) and quality != 0:
  _set_quality(0)
 elif Input.is_key_pressed(KEY_F2) and quality != 1:
  _set_quality(1)
 elif Input.is_key_pressed(KEY_F3) and quality != 2:
  _set_quality(2)
 _update_hud()

func _select_nearest() -> void:
 if is_instance_valid(chosen):
  chosen.set_selected(false)
 var nearest: AetherMob = null
 var shortest: float = 35.0
 # Cycling by choosing the next nearest enemy after the current target.
 for m in mobs:
  if not m.active:
   continue
  var length: float = hero.global_position.distance_to(m.global_position)
  if m == chosen:
   continue
  if length < shortest:
   shortest = length
   nearest = m
 if nearest == null and is_instance_valid(chosen) and chosen.active:
  nearest = chosen
 chosen = nearest
 hero.set_target(chosen)
 if pet != null:
  pet.current_mob = chosen
 if chosen != null:
  chosen.set_selected(true)
  info("Цель: %s, уровень %d. Дистанция: %.1f м" % [chosen.display_name, chosen.level, shortest])
 else:
  info("Рядом нет доступных монстров.")

func _hero_hit(mob: AetherMob, damage: int) -> void:
 mob.receive_hit(damage)
 info("%s: -%d HP" % [mob.display_name, damage])

func _mob_hurt(mob: AetherMob, _amount: int) -> void:
 if mob == chosen and target_label != null:
  target_label.text = "%s  •  Ур. %d\n%d / %d HP" % [mob.display_name, mob.level, mob.health, mob.max_health]

func _mob_defeated(mob: AetherMob) -> void:
 var reward: int = 5 + mob.level * 4
 inventory["gold"] = int(inventory["gold"]) + reward
 var leveled: bool = hero.gain_experience(mob.xp_reward)
 var output: String = "Победа: %s!  +%d опыта, +%d золота." % [mob.display_name, mob.xp_reward, reward]
 if leveled:
  output += " НОВЫЙ УРОВЕНЬ %d!" % hero.level
 if rng.randf() < (0.40 if mob.elite else 0.18):
  inventory["card"] = int(inventory["card"]) + 1
  output += " Выпала карта приручения!"
 if rng.randf() < 0.33:
  inventory["potion"] = int(inventory["potion"]) + 1
  output += " Зелье здоровья!"
 if pet != null:
  if pet.gain_experience(mob.xp_reward):
   output += " Питомец вырос до %d ур.!" % pet.pet_level
 if chosen == mob:
  mob.set_selected(false)
  chosen = null
  hero.set_target(null)
  if pet != null:
   pet.current_mob = null
 info(output)

func _toggle_pet() -> void:
 if not pet_unlocked:
  info("Питомец ещё не приручён. Ослабь монстра и нажми T (карта нужна).")
  return
 if pet != null:
  pet_level_saved = pet.pet_level
  pet_xp_saved = pet.pet_experience
  pet.queue_free()
  pet = null
  info("Питомец отозван.")
 else:
  pet = PET_SCENE.new() as AetherPet
  pet.owner_player = hero
  add_child(pet)
  pet.global_position = hero.global_position + Vector3(1.4, 0, 1.0)
  pet.build(self)
  pet.pet_level = pet_level_saved
  pet.pet_experience = pet_xp_saved
  pet.current_mob = chosen
  pet.struck.connect(_pet_hit)
  info("Призван: Сумеречный зверёк, ур. %d" % pet.pet_level)

func _pet_hit(mob: AetherMob, damage: int) -> void:
 mob.receive_hit(damage)

func _try_tame() -> void:
 if int(inventory["card"]) < 1:
  info("Нет карт приручения. Их можно найти с монстров.")
  return
 if chosen == null or not chosen.active or chosen.elite:
  info("Выбери обычного живого монстра: Tab")
  return
 if hero.global_position.distance_to(chosen.global_position) > 6.0:
  info("Подойди ближе (до 6 метров).")
  return
 if chosen.health > float(chosen.max_health) * 0.5:
  info("Ослабь цель до 50% здоровья, затем нажми T.")
  return
 inventory["card"] = int(inventory["card"]) - 1
 if rng.randf() <= 0.65:
  pet_unlocked = true
  chosen.set_selected(false)
  chosen.capture()
  chosen = null
  hero.set_target(null)
  if pet != null:
   pet.current_mob = null
  info("УСПЕХ! Существо приручено. Нажми P, чтобы призвать спутника.")
 else:
  info("Приручение не удалось. Карта потрачена — это часть игрового риска.")

func _drink_potion() -> void:
 if int(inventory["potion"]) <= 0:
  info("Зелья закончились.")
  return
 if hero.health >= hero.max_health:
  info("Здоровье уже полное.")
  return
 inventory["potion"] = int(inventory["potion"]) - 1
 hero.restore_from_potion()
 info("Выпито зелье: +70 HP")

func info(value: String) -> void:
 last_message = value
 message_timer = 5.0
 if message_label != null:
  message_label.text = value

func _toggle_backpack() -> void:
 backpack_frame.visible = not backpack_frame.visible
 _update_backpack()

func _save_game() -> void:
 if hero == null:
  return
 var save_data: Dictionary = {
  "version": 2, "lvl": hero.level, "xp": hero.experience, "health": hero.health,
  "mana": hero.mana, "px": hero.global_position.x, "pz": hero.global_position.z,
  "gold": int(inventory["gold"]), "potion": int(inventory["potion"]),
  "card": int(inventory["card"]), "pet_unlocked": pet_unlocked,
  "pet_lvl": pet.pet_level if pet != null else pet_level_saved,
  "pet_xp": pet.pet_experience if pet != null else pet_xp_saved
 }
 var file: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
 if file != null:
  file.store_string(JSON.stringify(save_data))
  file.close()

func _load_save() -> void:
 if not FileAccess.file_exists(SAVE_PATH):
  return
 var file: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.READ)
 if file == null:
  return
 var data: Variant = JSON.parse_string(file.get_as_text())
 file.close()
 if not (data is Dictionary) or int(data.get("version", 0)) != 2:
  return
 hero.level = maxi(1, int(data.get("lvl", 1)))
 hero.experience = maxi(0, int(data.get("xp", 0)))
 hero.max_health = 125 + (hero.level - 1) * 19
 hero.max_mana = 90 + (hero.level - 1) * 10
 hero.health = clampi(int(data.get("health", hero.max_health)), 1, hero.max_health)
 hero.mana = clampi(int(data.get("mana", hero.max_mana)), 0, hero.max_mana)
 var x: float = clampf(float(data.get("px", 0)), -178.0, 178.0)
 var z: float = clampf(float(data.get("pz", 18)), -230.0, 93.0)
 hero.global_position = Vector3(x, 0.3, z)
 inventory = {"gold": maxi(0, int(data.get("gold", 0))), "potion": maxi(0, int(data.get("potion", 3))), "card": maxi(0, int(data.get("card", 2)))}
 pet_unlocked = bool(data.get("pet_unlocked", false))
 pet_level_saved = maxi(1, int(data.get("pet_lvl", 1)))
 pet_xp_saved = maxi(0, int(data.get("pet_xp", 0)))
 info("Сохранение найдено. Продолжаем приключение!")

func _set_quality(level_index: int) -> void:
 if quality == level_index:
  return
 quality = level_index
 world_sun.shadow_enabled = quality >= 1
 Engine.max_fps = 30 if quality == 0 else 60
 for item in foliage_instances:
  if item != null:
   item.visible = quality > 0 or item == foliage_instances[0] or item == foliage_instances[1]

func _exit_tree() -> void:
 # Saving as the player closes the game also works for a normal desktop exit.
 if hero != null and is_instance_valid(hero):
  _save_game()

func _panel(parent: Control, left: float, top: float, width: float, height: float, ax: float = 0.0, ay: float = 0.0) -> PanelContainer:
 var panel := PanelContainer.new()
 panel.anchor_left = ax
 panel.anchor_right = ax
 panel.anchor_top = ay
 panel.anchor_bottom = ay
 panel.offset_left = left
 panel.offset_top = top
 panel.offset_right = left + width
 panel.offset_bottom = top + height
 panel.mouse_filter = Control.MOUSE_FILTER_PASS
 var box_style := StyleBoxFlat.new()
 box_style.bg_color = Color(0.105, 0.125, 0.137, 0.83)
 box_style.border_color = Color(0.55, 0.51, 0.42, 0.9)
 box_style.set_border_width_all(1)
 box_style.set_corner_radius_all(5)
 box_style.content_margin_left = 8
 box_style.content_margin_right = 8
 box_style.content_margin_top = 5
 box_style.content_margin_bottom = 5
 panel.add_theme_stylebox_override("panel", box_style)
 parent.add_child(panel)
 return panel

func _label(parent: Node, content: String, font_size: int = 14, tint: Color = Color("e8e2d5")) -> Label:
 var l := Label.new()
 l.text = content
 l.add_theme_font_size_override("font_size", font_size)
 l.add_theme_color_override("font_color", tint)
 parent.add_child(l)
 return l

func _progress(parent: Control, tint: Color) -> ProgressBar:
 var p := ProgressBar.new()
 p.custom_minimum_size = Vector2(176, 12)
 p.show_percentage = false
 var base := StyleBoxFlat.new()
 base.bg_color = Color("3a3e42")
 base.set_corner_radius_all(2)
 p.add_theme_stylebox_override("background", base)
 var fill := StyleBoxFlat.new()
 fill.bg_color = tint
 fill.set_corner_radius_all(2)
 p.add_theme_stylebox_override("fill", fill)
 parent.add_child(p)
 return p

func _button(parent: Node, caption: String, size: Vector2, func_to_call: Callable) -> Button:
 var btn := Button.new()
 btn.text = caption
 btn.custom_minimum_size = size
 btn.add_theme_font_size_override("font_size", 14)
 btn.focus_mode = Control.FOCUS_NONE
 btn.pressed.connect(func_to_call)
 parent.add_child(btn)
 return btn

func _interface() -> void:
 var screen := CanvasLayer.new()
 screen.layer = 3
 add_child(screen)
 var root := Control.new()
 root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 root.mouse_filter = Control.MOUSE_FILTER_IGNORE
 screen.add_child(root)
 # PLAYER: classic top-left name and HP/MP bars.
 var frame: PanelContainer = _panel(root, 12, 10, 256, 84)
 var stats := VBoxContainer.new()
 stats.add_theme_constant_override("separation", 3)
 frame.add_child(stats)
 name_label = _label(stats, "Странник • ур. 1", 16, Color("f0dbaf"))
 hp_bar = _progress(stats, Color("a95349"))
 mp_bar = _progress(stats, Color("5479a3"))
 pet_frame = _panel(root, 12, 102, 256, 50)
 var pv := VBoxContainer.new()
 pet_frame.add_child(pv)
 pet_label = _label(pv, "Питомец: не приручён", 14, Color("d6c3a0"))
 _label(pv, "Приручи монстра клавишей T", 12, Color("b9b8ac"))
 # Target appears at the top center, and is hidden when nothing is selected.
 target_frame = _panel(root, -160, 10, 320, 64, 0.5, 0.0)
 var tv := VBoxContainer.new()
 target_frame.add_child(tv)
 target_label = _label(tv, "Цель не выбрана", 15)
 # Minimap is calculated from world and mob positions: no external map texture.
 var minimap_holder: PanelContainer = _panel(root, -176, 10, 164, 170, 1.0, 0.0)
 compass = MINIMAP_SCENE.new() as AetherMinimap
 compass.custom_minimum_size = Vector2(148, 148)
 compass.hero = hero
 compass.enemies = mobs
 minimap_holder.add_child(compass)
 # Story + loot notices intentionally live away from the center of the game.
 var notice: PanelContainer = _panel(root, 12, 162, 385, 63)
 message_label = _label(notice, last_message, 13)
 message_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 # Old-school XP line immediately above the action bar.
 var experience_panel: PanelContainer = _panel(root, -348, -104, 696, 18, 0.5, 1.0)
 exp_bar = _progress(experience_panel, Color("b6a26f"))
 exp_bar.custom_minimum_size = Vector2(676, 8)
 var hotbar: PanelContainer = _panel(root, -352, -86, 704, 70, 0.5, 1.0)
 var slots := HBoxContainer.new()
 slots.alignment = BoxContainer.ALIGNMENT_CENTER
 slots.add_theme_constant_override("separation", 4)
 hotbar.add_child(slots)
 attack_button = _button(slots, "1\nАтака", Vector2(80, 53), Callable(hero, "toggle_autoattack"))
 _button(slots, "2\nСильный", Vector2(80, 53), Callable(hero, "heavy_attack"))
 _button(slots, "3\nЛечение", Vector2(80, 53), Callable(hero, "self_heal"))
 _button(slots, "TAB\nЦель", Vector2(80, 53), Callable(self, "_select_nearest"))
 _button(slots, "T\nПриручить", Vector2(80, 53), Callable(self, "_try_tame"))
 _button(slots, "P\nПитомец", Vector2(80, 53), Callable(self, "_toggle_pet"))
 _button(slots, "R\nЗелье", Vector2(80, 53), Callable(self, "_drink_potion"))
 _button(slots, "I\nСумка", Vector2(80, 53), Callable(self, "_toggle_backpack"))
 status_label = _label(root, "", 13, Color("e7dcb8"))
 status_label.anchor_left = 0.5
 status_label.anchor_right = 0.5
 status_label.anchor_top = 1.0
 status_label.anchor_bottom = 1.0
 status_label.offset_left = -345
 status_label.offset_right = 350
 status_label.offset_top = -131
 status_label.offset_bottom = -107
 status_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
 # Touch joystick: works with multi-touch alongside attack/skill buttons.
 var stick: AetherVirtualJoystick = JOYSTICK_SCENE.new() as AetherVirtualJoystick
 stick.anchor_left = 0
 stick.anchor_right = 0
 stick.anchor_top = 1
 stick.anchor_bottom = 1
 stick.offset_left = 20
 stick.offset_right = 194
 stick.offset_top = -201
 stick.offset_bottom = -27
 root.add_child(stick)
 stick.direction_changed.connect(func(vec: Vector2) -> void: hero.touch_move = vec)
 # Extra enlarged controls on the right for fingers; old-school hotbar stays.
 var mobile_bar := VBoxContainer.new()
 mobile_bar.anchor_left = 1.0
 mobile_bar.anchor_right = 1.0
 mobile_bar.anchor_top = 1.0
 mobile_bar.anchor_bottom = 1.0
 mobile_bar.offset_left = -167
 mobile_bar.offset_right = -12
 mobile_bar.offset_top = -330
 mobile_bar.offset_bottom = -113
 mobile_bar.add_theme_constant_override("separation", 5)
 root.add_child(mobile_bar)
 _button(mobile_bar, "ВЫБРАТЬ ЦЕЛЬ", Vector2(152, 46), Callable(self, "_select_nearest"))
 _button(mobile_bar, "АВТОАТАКА", Vector2(152, 46), Callable(hero, "toggle_autoattack"))
 _button(mobile_bar, "СИЛЬНЫЙ УДАР", Vector2(152, 46), Callable(hero, "heavy_attack"))
 _button(mobile_bar, "ПРИРУЧИТЬ", Vector2(152, 46), Callable(self, "_try_tame"))
 # The inventory is a usable panel, not a fake decorative icon.
 backpack_frame = _panel(root, -152, -170, 304, 252, 0.5, 0.5)
 backpack_label = _label(backpack_frame, "", 17)
 backpack_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 backpack_frame.visible = false
 _update_backpack()

func _update_hud() -> void:
 if hero == null or hp_bar == null:
  return
 hp_bar.max_value = hero.max_health
 hp_bar.value = hero.health
 hp_bar.tooltip_text = "HP: %d/%d" % [hero.health, hero.max_health]
 mp_bar.max_value = hero.max_mana
 mp_bar.value = hero.mana
 mp_bar.tooltip_text = "MP: %d/%d" % [hero.mana, hero.max_mana]
 exp_bar.max_value = hero.exp_to_next()
 exp_bar.value = hero.experience
 name_label.text = "Странник • ур. %d     HP %d/%d   MP %d/%d" % [hero.level, hero.health, hero.max_health, hero.mana, hero.max_mana]
 if pet != null:
  pet_label.text = "Питомец: Сумеречный зверёк +0 / ур. %d" % pet.pet_level
 elif pet_unlocked:
  pet_label.text = "Питомец: приручён (призвать P)"
 else:
  pet_label.text = "Питомец: не приручён"
 target_frame.visible = chosen != null and chosen.active
 if chosen != null and chosen.active:
  target_label.text = "%s • ур. %d\nHP %d / %d%s" % [chosen.display_name, chosen.level, chosen.health, chosen.max_health, "   • БОСС" if chosen.elite else ""]
 status_label.text = "XP %d/%d     Золото: %d     Карты: %d     Зелья: %d     %s" % [hero.experience, hero.exp_to_next(), int(inventory["gold"]), int(inventory["card"]), int(inventory["potion"]), "Автоатака: ВКЛ" if hero.auto_attack else ""]
 if backpack_frame.visible:
  _update_backpack()

func _update_backpack() -> void:
 if backpack_label == null:
  return
 backpack_label.text = "ИНВЕНТАРЬ\n\nЗолото: %d\nЗелья здоровья: %d  (R)\nКарты приручения: %d  (T)\n\nПитомец: %s\n\nP — призыв/отзыв\nF5 — сохранение\nI — закрыть" % [int(inventory["gold"]), int(inventory["potion"]), int(inventory["card"]), "есть" if pet_unlocked else "ещё нет"]
