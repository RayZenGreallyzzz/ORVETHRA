extends Node3D

# Aetherfall v0.3 - PLAYABLE STREET / all geometry in assets/street_layout.json.
# The very same data file is used to render the optional outside-engine preview.
# This scene is intentionally a small, testable 3D vertical slice.
const PLAYER_CLASS = preload("res://scripts/player.gd")
const JOYSTICK_CLASS = preload("res://scripts/virtual_joystick.gd")

var hero: AetherPlayer
var roof_materials: Dictionary = {}
var tinted_materials: Dictionary = {}
var building_zones: Array[Dictionary] = []
var fps_label: Label
var inside_label: Label
var info_label: Label
var preview_time: float = 0.0
var quality: int = 1
var sunlight: DirectionalLight3D

func _ready() -> void:
 _setup_world()
 _load_layout()
 hero = PLAYER_CLASS.new() as AetherPlayer
 hero.position = Vector3(0.0, 0.24, 25.0)
 hero.camera_distance = 8.2
 hero.camera_pitch = -0.24
 add_child(hero)
 _create_ui()
 _set_quality(0 if OS.has_feature("mobile") else 1)

func _setup_world() -> void:
 var we := WorldEnvironment.new()
 var env := Environment.new()
 env.background_mode = Environment.BG_COLOR
 env.background_color = Color("a4b4b5")
 env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
 env.ambient_light_color = Color("c0c7c0")
 env.ambient_light_energy = 0.71
 env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
 env.fog_enabled = true
 env.fog_light_color = Color("a6afa7")
 env.fog_density = 0.007
 we.environment = env
 add_child(we)
 sunlight = DirectionalLight3D.new()
 sunlight.rotation_degrees = Vector3(-55, -32, 0)
 sunlight.light_color = Color("f2e3c7")
 sunlight.light_energy = 1.13
 sunlight.shadow_enabled = true
 sunlight.directional_shadow_max_distance = 58.0
 add_child(sunlight)

func _load_layout() -> void:
 var f := FileAccess.open("res://assets/street_layout.json", FileAccess.READ)
 if f == null:
  push_error("Не найден файл res://assets/street_layout.json")
  return
 var parsed: Variant = JSON.parse_string(f.get_as_text())
 if typeof(parsed) != TYPE_DICTIONARY:
  push_error("Неверный формат геометрии города")
  return
 var layout: Dictionary = parsed
 for raw in layout.get("world_parts", []):
  _mesh_piece(self, raw, "")
 for raw_house in layout.get("buildings", []):
  var house: Dictionary = raw_house
  var pivot := Node3D.new()
  var house_id: String = str(house.get("id", "house"))
  pivot.name = house_id
  pivot.position = _v3(house.get("at", [0, 0, 0]))
  pivot.rotation_degrees.y = float(house.get("yaw", 0))
  add_child(pivot)
  for piece in house.get("parts", []):
   _mesh_piece(pivot, piece, house_id)
  building_zones.append({"pivot": pivot, "id": house_id, "label": str(house.get("label", "Дом")), "inside": house.get("inside", [3.1, 3.0])})
  _house_sign(pivot, str(house.get("label", "Дом")))

func _v3(x: Variant) -> Vector3:
 return Vector3(float(x[0]), float(x[1]), float(x[2]))

func _surface_material(piece: Dictionary, house_id: String) -> StandardMaterial3D:
 var tint: Color = Color(str(piece.get("color", "#ffffff")))
 var texture_name: String = str(piece.get("tex", ""))
 var fade_roof: bool = bool(piece.get("roof", false)) and house_id != ""
 var key: String = "%s/%s/%s/%s" % [tint.to_html(), texture_name, house_id if fade_roof else "world", "roof" if fade_roof else "flat"]
 if tinted_materials.has(key):
  return tinted_materials[key] as StandardMaterial3D
 var mat := StandardMaterial3D.new()
 mat.albedo_color = tint
 mat.roughness = 0.88
 mat.metallic = 0.0
 if str(piece.get("kind", "")) == "crystal":
  mat.cull_mode = BaseMaterial3D.CULL_DISABLED
 if texture_name != "":
  var tex: Texture2D = load("res://assets/%s.png" % texture_name)
  if tex != null:
   mat.albedo_texture = tex
   mat.uv1_scale = Vector3(1.6, 1.6, 1.6)
 if bool(piece.get("emissive", false)):
  mat.emission_enabled = true
  mat.emission = tint
  mat.emission_energy_multiplier = 0.5
 if fade_roof:
  mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
  mat.cull_mode = BaseMaterial3D.CULL_DISABLED
  mat.set_meta("roof_color", tint)
  if not roof_materials.has(house_id):
   roof_materials[house_id] = []
  (roof_materials[house_id] as Array).append(mat)
 tinted_materials[key] = mat
 return mat

func _mesh_piece(parent: Node3D, raw_piece: Variant, house_id: String) -> void:
 var part_data: Dictionary = raw_piece
 var mi := MeshInstance3D.new()
 var shape_size: Vector3 = _v3(part_data["size"])
 var mesh_kind: String = str(part_data.get("kind", "box"))
 match mesh_kind:
  "box":
   var mesh := BoxMesh.new()
   mesh.size = shape_size
   mi.mesh = mesh
  "sphere":
   var mesh := SphereMesh.new()
   mesh.radius = 0.5
   mesh.height = 1.0
   mesh.radial_segments = 9
   mesh.rings = 5
   mi.mesh = mesh
   mi.scale = shape_size
  "cylinder", "cone":
   var mesh := CylinderMesh.new()
   mesh.top_radius = 0.0 if mesh_kind == "cone" else 0.5
   mesh.bottom_radius = 0.5
   mesh.height = 1.0
   mesh.radial_segments = 8
   mi.mesh = mesh
   mi.scale = shape_size
  "crystal":
   mi.mesh = _crystal_mesh()
   mi.scale = shape_size
  _:
   return
 mi.position = _v3(part_data["at"])
 if part_data.has("rot"):
  mi.rotation_degrees = _v3(part_data["rot"])
 mi.material_override = _surface_material(part_data, house_id)
 mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF if bool(part_data.get("roof", false)) else GeometryInstance3D.SHADOW_CASTING_SETTING_ON
 parent.add_child(mi)
 if bool(part_data.get("solid", false)) and mesh_kind == "box":
  var body := StaticBody3D.new()
  body.collision_layer = 1
  body.position = mi.position
  body.rotation = mi.rotation
  var c := CollisionShape3D.new()
  var s := BoxShape3D.new()
  s.size = shape_size
  c.shape = s
  body.add_child(c)
  parent.add_child(body)

func _crystal_mesh() -> ArrayMesh:
 # Eight triangular faces, with sensible normals (original low-poly crystal).
 var up := Vector3(0, 0.5, 0)
 var down := Vector3(0, -0.5, 0)
 var rim: Array[Vector3] = [Vector3(0.5, 0, 0), Vector3(0, 0, 0.5), Vector3(-0.5, 0, 0), Vector3(0, 0, -0.5)]
 var st := SurfaceTool.new()
 st.begin(Mesh.PRIMITIVE_TRIANGLES)
 for k in range(4):
  var a: Vector3 = rim[k]
  var b: Vector3 = rim[(k + 1) % 4]
  for triangle in [[a, up, b], [b, down, a]]:
   var normal: Vector3 = (triangle[1] - triangle[0]).cross(triangle[2] - triangle[0]).normalized()
   for p in triangle:
    st.set_normal(normal)
    st.add_vertex(p)
 return st.commit()

func _house_sign(pivot: Node3D, title: String) -> void:
 var label := Label3D.new()
 label.text = title
 label.font_size = 70
 label.pixel_size = 0.0043
 label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
 label.modulate = Color("e9dbb9")
 label.outline_modulate = Color("292e2e")
 label.outline_size = 6
 label.position = Vector3(0.0, 3.80, 4.09)
 pivot.add_child(label)

func _process(delta: float) -> void:
 if hero == null:
  return
 var place_name: String = "Улица Ремесленников"
 for zone in building_zones:
  var pivot: Node3D = zone["pivot"]
  var local: Vector3 = pivot.to_local(hero.global_position)
  var inside: Array = zone["inside"]
  var is_inside: bool = absf(local.x) < float(inside[0]) and absf(local.z) < float(inside[1]) and local.y < 4.0
  var roof_id: String = str(zone["id"])
  var target_alpha: float = 0.07 if is_inside else 1.0
  for material in roof_materials.get(roof_id, []):
   var m: StandardMaterial3D = material
   var col: Color = m.get_meta("roof_color")
   col.a = move_toward(m.albedo_color.a, target_alpha, 1.7 * delta)
   m.albedo_color = col
  if is_inside:
   place_name = str(zone["label"])
 if inside_label != null:
  inside_label.text = place_name
 preview_time += delta
 if preview_time > 0.6 and fps_label != null:
  preview_time = 0.0
  fps_label.text = "%d FPS · %s" % [int(Performance.get_monitor(Performance.TIME_FPS)), "Эконом" if quality == 0 else "Красиво"]

func _unhandled_input(event: InputEvent) -> void:
 if event is InputEventKey and event.pressed and not event.echo:
  if event.physical_keycode == KEY_F6:
   _set_quality(0 if quality == 1 else 1)
  elif event.physical_keycode == KEY_F2:
   _start_adventure()

func _set_quality(v: int) -> void:
 quality = v
 if sunlight != null:
  sunlight.shadow_enabled = quality > 0
 Engine.max_fps = 30 if quality == 0 else 60

func _start_adventure() -> void:
 get_tree().change_scene_to_file("res://scenes/adventure.tscn")

func _make_panel(parent: Control) -> PanelContainer:
 var panel := PanelContainer.new()
 var sb := StyleBoxFlat.new()
 sb.bg_color = Color(0.105, 0.13, 0.14, 0.80)
 sb.border_color = Color(0.50, 0.50, 0.43, 0.8)
 sb.set_border_width_all(1)
 sb.set_corner_radius_all(6)
 sb.content_margin_left = 11
 sb.content_margin_right = 11
 sb.content_margin_top = 8
 sb.content_margin_bottom = 8
 panel.add_theme_stylebox_override("panel", sb)
 parent.add_child(panel)
 return panel

func _label(parent: Node, s: String, f: int, color: Color = Color("e8dfd0")) -> Label:
 var l := Label.new()
 l.text = s
 l.add_theme_font_size_override("font_size", f)
 l.add_theme_color_override("font_color", color)
 parent.add_child(l)
 return l

func _create_ui() -> void:
 var layer := CanvasLayer.new()
 layer.layer = 5
 add_child(layer)
 var root := Control.new()
 root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 root.mouse_filter = Control.MOUSE_FILTER_IGNORE
 layer.add_child(root)
 # HUD in spirit of small early-2000s RPG panels, with an actual 3D scene unobscured.
 var top_left := _make_panel(root)
 top_left.position = Vector2(16, 16)
 var v := VBoxContainer.new()
 v.add_theme_constant_override("separation", 4)
 top_left.add_child(v)
 _label(v, "AETHERFALL  ·  3D CITY TEST", 16, Color("e6c88e"))
 inside_label = _label(v, "Улица Ремесленников", 14)
 _label(v, "Три здания · настоящие входы", 12, Color("bec5bb"))
 var fps_frame := _make_panel(root)
 fps_frame.anchor_left = 1.0
 fps_frame.anchor_right = 1.0
 fps_frame.offset_left = -192
 fps_frame.offset_right = -14
 fps_frame.offset_top = 17
 fps_frame.offset_bottom = 55
 fps_label = _label(fps_frame, "FPS · Красиво", 12)
 var bottom := _make_panel(root)
 bottom.anchor_left = 0.5
 bottom.anchor_right = 0.5
 bottom.anchor_top = 1.0
 bottom.anchor_bottom = 1.0
 bottom.offset_left = -294
 bottom.offset_right = 294
 bottom.offset_top = -81
 bottom.offset_bottom = -15
 var actions := HBoxContainer.new()
 actions.add_theme_constant_override("separation", 10)
 bottom.add_child(actions)
 var b := Button.new()
 b.text = "В мир  →"
 b.custom_minimum_size = Vector2(105, 46)
 b.focus_mode = Control.FOCUS_NONE
 b.pressed.connect(_start_adventure)
 actions.add_child(b)
 var q := Button.new()
 q.text = "Графика"
 q.custom_minimum_size = Vector2(109, 46)
 q.focus_mode = Control.FOCUS_NONE
 q.pressed.connect(func() -> void: _set_quality(0 if quality == 1 else 1))
 actions.add_child(q)
 var helper := _label(actions, "WASD — ходить\nМышь — камера · войди в дом", 12)
 helper.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
 # Mobile movement stick on the left. Camera rotates by dragging the right half of the screen.
 var stick: AetherVirtualJoystick = JOYSTICK_CLASS.new() as AetherVirtualJoystick
 stick.anchor_left = 0.0
 stick.anchor_right = 0.0
 stick.anchor_top = 1.0
 stick.anchor_bottom = 1.0
 stick.offset_left = 21
 stick.offset_right = 195
 stick.offset_top = -208
 stick.offset_bottom = -34
 root.add_child(stick)
 stick.direction_changed.connect(func(dir: Vector2) -> void: hero.touch_move = dir)
