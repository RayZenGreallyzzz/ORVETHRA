extends Node3D
class_name AetherHouse

# The roof is a different material from the walls, so it can fade when a
# character enters the walkable interior instead of hiding the whole house.
var roof_material: StandardMaterial3D
var roof_base: Color = Color("647584")
var roof_alpha: float = 1.0
var local_bounds: Vector2 = Vector2(3.2, 3.0)

func build(world, wall: Color, roof: Color, label_text: String) -> void:
 roof_base = roof
 var stone: Material = world.material(wall)
 var wood: Material = world.material(Color("6d5849"))
 var dark: Material = world.material(Color("413b39"))
 var glass: Material = world.material(Color("789fa4"))
 var pale: Material = world.material(Color("b7a78b"))
 # Base floor + solid walls, with a real door gap in the front (+Z).
 world.box_part(self, Vector3(0, 0.006, 0), Vector3(6.3, 0.012, 5.9), pale)
 world.box_part(self, Vector3(-3.0, 1.86, 0), Vector3(0.28, 3.72, 5.95), stone, true)
 world.box_part(self, Vector3(3.0, 1.86, 0), Vector3(0.28, 3.72, 5.95), stone, true)
 world.box_part(self, Vector3(0, 1.86, -2.95), Vector3(6.1, 3.72, 0.28), stone, true)
 world.box_part(self, Vector3(-2.03, 1.86, 2.95), Vector3(2.05, 3.72, 0.28), stone, true)
 world.box_part(self, Vector3(2.03, 1.86, 2.95), Vector3(2.05, 3.72, 0.28), stone, true)
 world.box_part(self, Vector3(0, 3.20, 2.95), Vector3(2.08, 1.04, 0.28), stone, true)
 for x in [-2.75, 2.75]:
  world.box_part(self, Vector3(x, 2.0, 3.14), Vector3(0.16, 3.9, 0.17), wood)
 for x in [-1.6, 1.6]:
  world.box_part(self, Vector3(x, 2.2, 3.13), Vector3(0.62, 0.82, 0.09), glass)
 world.box_part(self, Vector3(0, 3.85, 2.9), Vector3(2.65, 0.28, 0.25), wood)
 # Interior objects: physical floor, counter, shelves, stools and warm lamp.
 world.box_part(self, Vector3(-1.8, 1.25, -1.75), Vector3(2.2, 2.5, 0.42), wood)
 world.box_part(self, Vector3(1.15, 0.83, -1.0), Vector3(2.5, 0.18, 0.75), wood)
 world.box_part(self, Vector3(0.24, 0.45, 0.7), Vector3(0.95, 0.9, 0.85), dark)
 world.box_part(self, Vector3(-2.0, 0.12, 1.0), Vector3(1.05, 0.12, 1.2), world.material(Color("9b795d")))
 world.box_part(self, Vector3(-1.8, 2.18, -1.48), Vector3(0.5, 0.35, 0.5), world.material(Color("68796f")))
 world.box_part(self, Vector3(0.7, 3.25, 0), Vector3(0.25, 0.28, 0.25), world.glow_material(Color("e8b678")))
 roof_material = StandardMaterial3D.new()
 roof_material.albedo_color = roof
 roof_material.roughness = 0.95
 roof_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
 roof_material.cull_mode = BaseMaterial3D.CULL_DISABLED
 # Two pitched roof planes, ridge runs front to back.
 var left_roof: MeshInstance3D = world.box_part(self, Vector3(-1.55, 4.38, 0), Vector3(3.8, 0.22, 6.8), roof_material)
 left_roof.rotation.z = -0.48
 var right_roof: MeshInstance3D = world.box_part(self, Vector3(1.55, 4.38, 0), Vector3(3.8, 0.22, 6.8), roof_material)
 right_roof.rotation.z = 0.48
 world.box_part(self, Vector3(0, 5.08, 0), Vector3(0.3, 0.26, 6.95), wood)
 # Shop sign: a readable label floating above the door.
 var sign_label := Label3D.new()
 sign_label.text = label_text
 sign_label.font_size = 44
 sign_label.pixel_size = 0.005
 sign_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
 sign_label.modulate = Color("e4d4ab")
 sign_label.position = Vector3(0, 3.65, 3.4)
 add_child(sign_label)

func update_for_player(player_world_position: Vector3, delta: float) -> void:
 if roof_material == null:
  return
 var p: Vector3 = to_local(player_world_position)
 var inside: bool = absf(p.x) < local_bounds.x and absf(p.z) < local_bounds.y and p.y > -0.2 and p.y < 4.0
 var desired: float = 0.10 if inside else 1.0
 roof_alpha = move_toward(roof_alpha, desired, delta * 2.3)
 var col: Color = roof_base
 col.a = roof_alpha
 roof_material.albedo_color = col
