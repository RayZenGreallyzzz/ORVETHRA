extends Control

# ORVETHRA v0.5: offline UI walkthrough. Google Sign-In / servers are not connected.
const PROFILE_FILE := "user://orvethra_guest_profile.json"
const COVER := "res://assets/title_cover.jpg"

var screen: String = "home"
var backdrop: TextureRect
var view: Control
var nickname: LineEdit
var race_choice: OptionButton
var class_choice: OptionButton
var hero_data: Dictionary = {}
var graphics_quality: bool = false

func _ready() -> void:
	Engine.max_fps = 30
	_load_profile()
	_build_background()
	view = Control.new()
	view.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	view.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(view)
	_show("home")

func _build_background() -> void:
	var base := ColorRect.new()
	base.color = Color("172331")
	base.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(base)
	if ResourceLoader.exists(COVER):
		backdrop = TextureRect.new()
		backdrop.texture = load(COVER)
		backdrop.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		backdrop.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		backdrop.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(backdrop)
	else:
		var tint := ColorRect.new()
		tint.color = Color("273747")
		tint.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		tint.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(tint)

func _show(page: String) -> void:
	screen = page
	for child in view.get_children():
		view.remove_child(child)
		child.queue_free()
	if page == "home":
		_home()
		return
	var shade := ColorRect.new()
	shade.color = Color(0.025, 0.035, 0.055, 0.87)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_STOP
	view.add_child(shade)
	var frame := PanelContainer.new()
	frame.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	frame.offset_left = -316
	frame.offset_right = 316
	frame.offset_top = -253
	frame.offset_bottom = 253
	frame.add_theme_stylebox_override("panel", _style(Color("162437"), Color("b99c67"), 3))
	view.add_child(frame)
	var wrap := MarginContainer.new()
	wrap.add_theme_constant_override("margin_left", 28)
	wrap.add_theme_constant_override("margin_right", 28)
	wrap.add_theme_constant_override("margin_top", 24)
	wrap.add_theme_constant_override("margin_bottom", 24)
	frame.add_child(wrap)
	var body := VBoxContainer.new()
	body.add_theme_constant_override("separation", 14)
	wrap.add_child(body)
	match page:
		"login": _login(body)
		"servers": _servers(body)
		"characters": _characters(body)
		"create": _create_character(body)
		"settings": _settings(body)
		"authors": _authors(body)

func _style(bg: Color, border: Color, roundness: int = 8) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(2)
	s.set_corner_radius_all(roundness)
	s.content_margin_left = 10
	s.content_margin_right = 10
	s.content_margin_top = 6
	s.content_margin_bottom = 6
	return s

func _button(container: Node, name: String, action: Callable, primary: bool = false) -> Button:
	var b := Button.new()
	b.text = name
	b.custom_minimum_size = Vector2(0, 52)
	b.add_theme_font_size_override("font_size", 21)
	b.add_theme_color_override("font_color", Color("f8e6c1"))
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_stylebox_override("normal", _style(Color("17415b") if primary else Color("293039"), Color("dcb76c") if primary else Color("957f5c")))
	b.add_theme_stylebox_override("hover", _style(Color("245673"), Color("ebd08b")))
	b.add_theme_stylebox_override("pressed", _style(Color("0d3048"), Color("e7cd7f")))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.pressed.connect(action)
	container.add_child(b)
	return b

func _label(container: Node, message: String, size: int = 20, centered: bool = true) -> Label:
	var l := Label.new()
	l.text = message
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER if centered else HORIZONTAL_ALIGNMENT_LEFT
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.add_theme_color_override("font_color", Color("eddbc0"))
	l.add_theme_font_size_override("font_size", size)
	container.add_child(l)
	return l

func _heading(body: VBoxContainer, name: String, description: String = "") -> void:
	_label(body, "✦  " + name + "  ✦", 31)
	if description != "":
		_label(body, description, 18)
	var space := Control.new()
	space.custom_minimum_size.y = 8
	body.add_child(space)

func _home() -> void:
	# Full-resolution artwork already contains the typography and button art.
	# Place large transparent touch targets over these decorative elements.
	if backdrop != null:
		_hotspot(0.43, 0.63, 0.68, 0.727, func(): _show("login"))
		_hotspot(0.475, 0.737, 0.635, 0.788, func(): _show("settings"))
		_hotspot(0.475, 0.797, 0.635, 0.845, func(): _show("authors"))
		_hotspot(0.475, 0.853, 0.635, 0.909, func(): get_tree().quit())
	else:
		var box := VBoxContainer.new()
		box.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
		box.offset_left = -235
		box.offset_right = 235
		box.offset_top = -240
		box.offset_bottom = 260
		box.add_theme_constant_override("separation", 15)
		view.add_child(box)
		_label(box, "ORVETHRA", 58)
		_label(box, "Мир забытых легенд", 23)
		_button(box, "Начать приключение", func(): _show("login"), true)
		_button(box, "Настройки", func(): _show("settings"))
		_button(box, "Авторы", func(): _show("authors"))
		_button(box, "Выход", func(): get_tree().quit())

func _hotspot(x1: float, y1: float, x2: float, y2: float, action: Callable) -> void:
	var b := Button.new()
	b.text = ""
	b.anchor_left = x1
	b.anchor_top = y1
	b.anchor_right = x2
	b.anchor_bottom = y2
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	b.add_theme_stylebox_override("normal", StyleBoxEmpty.new())
	b.add_theme_stylebox_override("hover", _style(Color(0.13, 0.47, 0.77, 0.17), Color(0.86, 0.7, 0.37, 0.68)))
	b.add_theme_stylebox_override("pressed", _style(Color(0.13, 0.47, 0.77, 0.27), Color(0.86, 0.7, 0.37)))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.pressed.connect(action)
	view.add_child(b)

func _login(body: VBoxContainer) -> void:
	_heading(body, "Вход в ORVETHRA", "Подключите аккаунт или запустите офлайн-тест.")
	_button(body, "Войти через Google", func(): _message("Google-вход пока не подключён. Для реальной авторизации потребуется OAuth и серверная проверка."), true)
	_label(body, "Для Google нужны настройка OAuth и безопасный сервер.\nВ этой версии вход не выполняется.", 17)
	_button(body, "Продолжить как гость (тест)", func(): _show("servers"))
	_button(body, "← Назад", func(): _show("home"))

func _servers(body: VBoxContainer) -> void:
	_heading(body, "Выбор мира", "Проверка экранов. Онлайн-сервер ещё не запущен.")
	_button(body, "ORVETHRA · Локальный мир", func(): _show("characters"), true)
	_label(body, "Офлайн-тест на устройстве.\nСетевая игра будет добавлена позже.", 17)
	_button(body, "← Назад", func(): _show("login"))

func _characters(body: VBoxContainer) -> void:
	_heading(body, "Выбор персонажа")
	if hero_data.is_empty():
		_label(body, "Пока нет созданных героев.", 18)
	else:
		var summary := "%s\n%s · %s" % [str(hero_data.get("name", "Герой")), str(hero_data.get("race", "Человек")), str(hero_data.get("class", "Странник"))]
		_label(body, summary, 24)
		_button(body, "Войти в мир", func(): _enter_world(), true)
	_button(body, "Создать персонажа" if hero_data.is_empty() else "Изменить персонажа", func(): _show("create"), hero_data.is_empty())
	_button(body, "← Назад", func(): _show("servers"))

func _create_character(body: VBoxContainer) -> void:
	_heading(body, "Создание героя")
	_label(body, "Имя персонажа", 19, false)
	nickname = LineEdit.new()
	nickname.placeholder_text = "Введите имя (2–18 символов)"
	nickname.text = str(hero_data.get("name", ""))
	nickname.custom_minimum_size.y = 48
	body.add_child(nickname)
	_label(body, "Раса", 19, false)
	race_choice = OptionButton.new()
	for item in ["Человек", "Эльф", "Гном"]:
		race_choice.add_item(item)
	race_choice.custom_minimum_size.y = 46
	body.add_child(race_choice)
	_label(body, "Класс", 19, false)
	class_choice = OptionButton.new()
	for item in ["Воин", "Маг", "Лучник", "Ассасин", "Призыватель", "Жрец"]:
		class_choice.add_item(item)
	class_choice.custom_minimum_size.y = 46
	body.add_child(class_choice)
	if not hero_data.is_empty():
		for i in range(race_choice.item_count):
			if race_choice.get_item_text(i) == str(hero_data.get("race", "")):
				race_choice.select(i)
		for i in range(class_choice.item_count):
			if class_choice.get_item_text(i) == str(hero_data.get("class", "")):
				class_choice.select(i)
	_button(body, "Сохранить героя", func(): _save_character(), true)
	_button(body, "← Назад", func(): _show("characters"))

func _save_character() -> void:
	var name_text := nickname.text.strip_edges()
	if name_text.length() < 2 or name_text.length() > 18:
		_message("Имя должно содержать от 2 до 18 символов.")
		return
	hero_data = {"name": name_text, "race": race_choice.get_item_text(race_choice.selected), "class": class_choice.get_item_text(class_choice.selected)}
	var file := FileAccess.open(PROFILE_FILE, FileAccess.WRITE)
	if file == null:
		_message("Не удалось сохранить тестового персонажа.")
		return
	file.store_string(JSON.stringify(hero_data))
	file.close()
	_show("characters")

func _load_profile() -> void:
	if not FileAccess.file_exists(PROFILE_FILE):
		return
	var content := FileAccess.get_file_as_string(PROFILE_FILE)
	var result: Variant = JSON.parse_string(content)
	if result is Dictionary:
		hero_data = result

func _enter_world() -> void:
	var world_path := "res://scenes/street_preview.tscn"
	if not ResourceLoader.exists(world_path):
		world_path = "res://scenes/town.tscn"
	if ResourceLoader.exists(world_path):
		get_tree().change_scene_to_file(world_path)
	else:
		_message("Мир пока не добавлен в эту сборку.")

func _settings(body: VBoxContainer) -> void:
	_heading(body, "Настройки", "Параметры для первого Android-теста.")
	_label(body, "Ограничение кадров", 19)
	_button(body, "Качество: %s" % ("60 FPS (тест)" if graphics_quality else "30 FPS (эконом)"), func(): _switch_quality(), true)
	_label(body, "Рекомендуем 30 FPS для IT-801C.\nЭто тестовая настройка лимита кадров.", 17)
	_button(body, "← Назад", func(): _show("home"))

func _switch_quality() -> void:
	graphics_quality = not graphics_quality
	Engine.max_fps = 60 if graphics_quality else 30
	_show("settings")

func _authors(body: VBoxContainer) -> void:
	_heading(body, "Авторы", "ORVETHRA — Мир забытых легенд")
	_label(body, "Независимая фэнтезийная RPG.\nВерсия 0.5 · Тестовое Android-меню\n\nРазработка продолжается.\nСейчас игра находится на стадии прототипа.", 19)
	_button(body, "← Назад", func(): _show("home"))

func _message(msg: String) -> void:
	var popup := AcceptDialog.new()
	popup.title = "ORVETHRA"
	popup.dialog_text = msg
	view.add_child(popup)
	popup.popup_centered(Vector2i(600, 230))
	popup.confirmed.connect(func(): popup.queue_free())
	popup.canceled.connect(func(): popup.queue_free())
